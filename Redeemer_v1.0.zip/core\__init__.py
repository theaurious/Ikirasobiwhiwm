"""Core module package for Redeemer automated redemption engine."""
