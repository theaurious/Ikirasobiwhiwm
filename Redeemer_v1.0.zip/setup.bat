@echo off
chcp 65001 >nul
title Redeemer - Setup & Dependency Installer
echo ======================================================================
echo           REDEEMER v1.0 — INITIAL SETUP & DEPENDENCY INSTALLER
echo ======================================================================
echo.

:: 1. Check Python
echo [*] Checking Python installation...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not found! Please install Python 3.10+ and add it to PATH.
    echo Download: https://www.python.org/downloads/
    pause
    exit /b 1
)
python --version

:: 2. Check Node.js
echo.
echo [*] Checking Node.js installation...
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not found! Please install Node.js (LTS version recommended).
    echo Download: https://nodejs.org/
    pause
    exit /b 1
)
node --version

:: 3. Install Node.js dependencies
echo.
echo [*] Installing Node dependencies (Patchright stealth browser engine)...
call npm install
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install npm dependencies.
    pause
    exit /b 1
)

:: 4. Install Chromium browser for Patchright
echo.
echo [*] Downloading Patchright Chromium browser binaries...
call npx patchright install chromium
if %errorlevel% neq 0 (
    echo [WARNING] Could not automatically download Chromium via patchright. You may need an internet connection.
)

:: 5. Install optional Python packages
echo.
echo [*] Installing optional Python dependencies...
python -m pip install -r requirements.txt --quiet
if %errorlevel% neq 0 (
    echo [INFO] Local OCR (ddddocr) is optional. Tool will use Tier 2 Cloud API or Tier 4 CLI prompt.
)

echo.
echo ======================================================================
echo  [SUCCESS] Redeemer setup completed successfully!
echo.
echo  Next steps:
echo    1. Add your accounts to acc.txt (or place cookies in cookies/ folder)
echo    2. Run run.bat (or python redeem.py) to start redeeming.
echo ======================================================================
echo.
pause
