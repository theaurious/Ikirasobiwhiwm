Place your cookie files here in JSON or Netscape format.
Supported naming conventions:
  - {email}.json
  - {email}.txt
  - {sanitized_email}.json

Example:
  cookies/user1@outlook.com.txt
