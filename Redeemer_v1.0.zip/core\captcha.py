#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""4-Tier Captcha Solver: Local Offline OCR -> Cloud API -> Fallback Notification -> Interactive CLI Manual Input."""

import base64
import json
import msvcrt
import os
import re
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional


def clean_code(raw: str) -> str:
    """Strip special characters, retaining only alphanumeric chars."""
    return re.sub(r"[^a-zA-Z0-9]", "", str(raw)).strip()


def sanitize_filename(name: str) -> str:
    """Create safe file name from email string."""
    return re.sub(r"[^a-zA-Z0-9_.-]", "_", str(name)).strip()


def solve_via_local_ocr(image_bytes: bytes) -> Optional[str]:
    """TIER 1: Local OCR recognition (if ddddocr is available in environment)."""
    try:
        import ddddocr  # type: ignore

        ocr = ddddocr.DdddOcr(show_ad=False)
        result = ocr.classification(image_bytes)
        code = clean_code(result)
        if len(code) == 6:
            return code
    except Exception:
        pass
    return None


def solve_via_api(image_bytes: bytes, service: str, api_key: str) -> Optional[str]:
    """TIER 2: Remote Captcha solver API (2Captcha, CapSolver, Anti-Captcha)."""
    if not api_key:
        return None

    b64_img = base64.b64encode(image_bytes).decode("ascii")

    try:
        # Standard 2Captcha API
        if service.lower() in ("2captcha", "twocaptcha"):
            create_url = "https://2captcha.com/in.php"
            form_data = urllib.parse.urlencode({
                "method": "base64",
                "key": api_key,
                "body": b64_img,
                "json": 1,
            }).encode("utf-8")

            req = urllib.request.Request(create_url, data=form_data)
            with urllib.request.urlopen(req, timeout=15) as resp:
                res_data = json.loads(resp.read().decode("utf-8"))

            if res_data.get("status") != 1:
                return None

            request_id = res_data.get("request")
            if not request_id:
                return None

            poll_url = f"https://2captcha.com/res.php?key={api_key}&action=get&id={request_id}&json=1"
            for _ in range(12):
                time.sleep(2)
                with urllib.request.urlopen(poll_url, timeout=10) as p_resp:
                    p_data = json.loads(p_resp.read().decode("utf-8"))
                if p_data.get("status") == 1:
                    code = clean_code(p_data.get("request", ""))
                    if len(code) == 6:
                        return code
                elif p_data.get("request") != "CAPCHA_NOT_READY":
                    break

        # Standard CapSolver API
        elif service.lower() == "capsolver":
            create_url = "https://api.capsolver.com/createTask"
            payload = json.dumps({
                "clientKey": api_key,
                "task": {"type": "ImageToTextTask", "body": b64_img},
            }).encode("utf-8")

            req = urllib.request.Request(create_url, data=payload, headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=15) as resp:
                res_data = json.loads(resp.read().decode("utf-8"))

            task_id = res_data.get("taskId")
            if not task_id:
                text = res_data.get("solution", {}).get("text", "")
                code = clean_code(text)
                if len(code) == 6:
                    return code
                return None

            res_url = "https://api.capsolver.com/getTaskResult"
            poll_payload = json.dumps({"clientKey": api_key, "taskId": task_id}).encode("utf-8")
            for _ in range(10):
                time.sleep(2)
                p_req = urllib.request.Request(res_url, data=poll_payload, headers={"Content-Type": "application/json"})
                with urllib.request.urlopen(p_req, timeout=10) as p_resp:
                    p_data = json.loads(p_resp.read().decode("utf-8"))
                if p_data.get("status") == "ready":
                    code = clean_code(p_data.get("solution", {}).get("text", ""))
                    if len(code) == 6:
                        return code

    except Exception:
        pass

    return None


def input_with_timeout_cli(prompt: str, timeout_sec: int = 60) -> Optional[str]:
    """TIER 4: Countdown timer and interactive manual keystroke reader on Windows Console."""
    print(prompt, end="", flush=True)
    start_time = time.time()
    chars = []

    while True:
        if msvcrt.kbhit():
            ch = msvcrt.getwch()
            if ch in ("\r", "\n"):
                print()
                return "".join(chars).strip()
            elif ch == "\b":
                if chars:
                    chars.pop()
                    sys.stdout.write("\b \b")
                    sys.stdout.flush()
            elif ord(ch) in (0, 224):
                msvcrt.getwch()
            else:
                chars.append(ch)
                sys.stdout.write(ch)
                sys.stdout.flush()

        elapsed = time.time() - start_time
        if elapsed > timeout_sec:
            print("\n  [!] Input timeout reached.")
            return None

        time.sleep(0.04)


def resolve_captcha_4tiers(
    image_bytes: bytes,
    email: str,
    config: Dict[str, Any],
    captchas_dir: Path,
) -> Optional[str]:
    """Execute 4-tier transparent captcha resolution pipeline."""
    captcha_cfg = config.get("captcha", {})
    api_service = captcha_cfg.get("api_service", "2captcha")
    api_key = captcha_cfg.get("api_key", "").strip()
    timeout_sec = int(captcha_cfg.get("manual_timeout_sec", 60))

    # TIER 1: Local Offline OCR
    print("  [*] [Tier 1] Trying local offline OCR...")
    local_code = solve_via_local_ocr(image_bytes)
    if local_code:
        print(f"  [+] [Tier 1] Solved locally: {local_code}")
        return local_code

    # TIER 2: Remote API (if key is configured)
    if api_key:
        print(f"  [*] [Tier 2] Submitting to API ({api_service})...")
        api_code = solve_via_api(image_bytes, api_service, api_key)
        if api_code:
            print(f"  [+] [Tier 2] Solved by API: {api_code}")
            return api_code

    # TIER 3: Explicit failure notification
    print("  [!] [Tier 3] Automated recognition could not resolve image code.")

    # TIER 4: Save image & Prompt manual CLI input
    captchas_dir.mkdir(parents=True, exist_ok=True)
    safe_name = sanitize_filename(email)
    img_path = captchas_dir / f"captcha_{safe_name}.png"
    try:
        with open(img_path, "wb") as f:
            f.write(image_bytes)
    except Exception as exc:
        print(f"  [X] Failed to save captcha image: {exc}")

    print("\n" + "=" * 70)
    print(f"  [📸] CAPTCHA SAVED: {img_path.resolve()}")
    print("  👉 Please open the image and enter the 6-character code here:")
    print("     (Type 's' to skip this account | Auto-skips after timeout)")
    print("=" * 70)

    user_in = input_with_timeout_cli(f"  👉 Enter 6 characters ({timeout_sec}s): ", timeout_sec=timeout_sec)
    if not user_in or user_in.lower() == "s":
        return None

    cleaned = clean_code(user_in)
    if len(cleaned) == 6:
        return cleaned

    print(f"  [!] Invalid input (requires 6 characters, received {len(cleaned)}).")
    return None
