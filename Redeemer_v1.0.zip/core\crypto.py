#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pure Python RSA-2048 PKCS#1 v1.5 encryption and RFC 6238 TOTP SHA-1 generator."""

import base64
import hashlib
import hmac
import json
import os
import random
import struct
import time
from typing import Any, Dict, Optional

# Original RSA 2048-bit Public Key extracted from Bing Android assets/appconfig_basic.json
REDEEM_PUBLIC_KEY_B64 = (
    "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAzvymntj521v4icYDUhEP"
    "8LOfrgo8qo0OL4oNN8tDp1j/jFgFhW+DkqJtSA1XXxprxi7bXiLKgDnGc9Mp+I/z"
    "T51qaUuCnR3HsBdtxJzvUZTKFCtQ4ldcQHFZGq4EVYRe6PaU8JpW6KBYbpxv52ry"
    "rYxyigMB4Ib0z+RsdJN5k4CXxoPvWSwnDgVG09EQPyuHKqAcb7xL4G7Z6hfZLbMg"
    "+dZ0DYfeMWHVflHoFlb6vM29/CniD/PJjU5RwL9UMIOdhd1Va2q6kN2b5G3jrzsu"
    "MIRpi7YrrozO/L1xLPnUqqcCrVhcyFoC/l8T4AHhFqHHBRxQics6T+TZVp90VMHN"
    "fQIDAQAB"
)

# Extract Modulus n and Exponent e from DER SubjectPublicKeyInfo
_DER_BYTES = base64.b64decode(REDEEM_PUBLIC_KEY_B64)
_MOD_IDX = _DER_BYTES.find(b"\x02\x82\x01\x01\x00")
if _MOD_IDX != -1:
    _N_BYTES = _DER_BYTES[_MOD_IDX + 5 : _MOD_IDX + 5 + 256]
    RSA_N = int.from_bytes(_N_BYTES, "big")
else:
    # Standard offset fallback in RSA 2048-bit SubjectPublicKeyInfo
    RSA_N = int.from_bytes(_DER_BYTES[33:289], "big")
RSA_E = 65537

# Standard Bing Sapphire Android User-Agents for API requests
SAPPHIRE_USER_AGENTS = [
    "SAAndroid/34.3.441014004 (Linux; U; Android 14; SM-S928B Build/UP1A.231005.007) BingApp/34.3.441014004",
    "SAAndroid/34.3.441014004 (Linux; U; Android 14; SM-S918B Build/UP1A.231005.007) BingApp/34.3.441014004",
    "SAAndroid/34.3.441014004 (Linux; U; Android 14; Pixel 8 Pro Build/UD1A.230803.041) BingApp/34.3.441014004",
    "SAAndroid/34.3.441014004 (Linux; U; Android 14; Pixel 7 Build/UD1A.230803.022) BingApp/34.3.441014004",
    "SAAndroid/34.3.441014004 (Linux; U; Android 14; 23127PN0CG Build/UKQ1.230804.001) BingApp/34.3.441014004",
]


def get_random_sapphire_ua() -> str:
    """Return a randomized standard Bing Android User-Agent."""
    return random.choice(SAPPHIRE_USER_AGENTS)


def derive_deterministic_uuid(email: str, ruid: str) -> str:
    """Derive deterministic Device UUID v4 strictly tied to email and ruid."""
    key = b"Microsoft-Sapphire-DeviceUniqueId-v1"
    msg = f"{str(email).strip().lower()}|{str(ruid).strip()}".encode("utf-8")
    digest = hmac.new(key, msg, hashlib.sha256).digest()
    raw = bytearray(digest[:16])
    raw[6] = (raw[6] & 0x0F) | 0x40  # version 4
    raw[8] = (raw[8] & 0x3F) | 0x80  # RFC 4122 variant
    h = raw.hex()
    return f"{h[0:8]}-{h[8:12]}-{h[12:16]}-{h[16:20]}-{h[20:32]}"


def generate_totp(secret_base32: str, period: int = 300, digits: int = 6, timestamp_ms: Optional[int] = None) -> str:
    """Generate RFC 6238 TOTP SHA-1 code in pure Python."""
    clean_secret = secret_base32.replace(" ", "").strip().upper()
    missing_padding = len(clean_secret) % 8
    if missing_padding:
        clean_secret += "=" * (8 - missing_padding)

    key = base64.b32decode(clean_secret)

    if timestamp_ms is None:
        server_sec = int(time.time())
    else:
        server_sec = int(timestamp_ms // 1000)

    counter = int(server_sec // period)
    msg = struct.pack(">Q", counter)
    digest = hmac.new(key, msg, hashlib.sha1).digest()

    offset = digest[-1] & 0x0F
    code_int = struct.unpack(">I", digest[offset : offset + 4])[0] & 0x7FFFFFFF
    return str(code_int % (10**digits)).zfill(digits)


def encrypt_rsa_pkcs1v15(plain_data: str) -> str:
    """Encrypt plain string with RSA 2048-bit PKCS#1 v1.5 padding in pure Python.
    
    Maximum plaintext payload for RSA 2048-bit PKCS#1 v1.5 is 245 bytes.
    """
    data_bytes = plain_data.encode("utf-8")
    data_len = len(data_bytes)
    key_size = 256  # 2048 bits = 256 bytes

    if data_len > 245:
        raise ValueError(f"Payload ({data_len} bytes) exceeds RSA 2048-bit limit of 245 bytes.")

    # PKCS#1 v1.5 padding: 0x00 || 0x02 || PS || 0x00 || Data
    # PS is non-zero pseudorandom bytes, minimum 8 bytes length
    ps_len = key_size - data_len - 3
    ps = bytearray()
    while len(ps) < ps_len:
        rand_byte = os.urandom(1)[0]
        if rand_byte != 0:
            ps.append(rand_byte)

    em = b"\x00\x02" + bytes(ps) + b"\x00" + data_bytes
    em_int = int.from_bytes(em, "big")

    # c = m^e mod n
    c_int = pow(em_int, RSA_E, RSA_N)
    c_bytes = c_int.to_bytes(key_size, "big")

    return base64.b64encode(c_bytes).decode("ascii")


def build_encrypted_metadata(email: str, ruid: str, timestamp_ms: int) -> str:
    """Package and encrypt device metadata matching WG() function in Bing Android protocol."""
    dev_id = derive_deterministic_uuid(email, ruid)
    meta_dict = {
        "userId": str(ruid).strip(),
        "timestamp": int(timestamp_ms),
        "device_info": {
            "isEmulator": False,
            "location": {"latitude": "", "longitude": ""},
            "device_id": dev_id,
        },
    }
    meta_json = json.dumps(meta_dict, separators=(",", ":"))
    return encrypt_rsa_pkcs1v15(meta_json)
