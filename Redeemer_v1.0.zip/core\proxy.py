#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Multi-protocol Proxy parser, normalizer and live health tester."""

import re
import socket
import urllib.parse
from typing import Dict, List, Optional, Tuple


def normalize_proxy_string(proxy_str: str) -> str:
    """Normalize raw proxy string to protocol://user:pass@host:port."""
    raw = proxy_str.strip()
    if not raw:
        return ""

    # Strip 'proxy:' prefix if present
    if raw.lower().startswith("proxy:"):
        raw = raw[6:].strip()

    # Extract protocol if already specified
    protocol = "http"
    if "://" in raw:
        protocol, raw = raw.split("://", 1)
        protocol = protocol.lower()

    # Reformat IP:Port:User:Pass -> User:Pass@IP:Port
    parts = raw.split(":")
    if len(parts) == 4 and not ("@" in raw):
        if parts[1].isdigit():
            ip, port, user, passwd = parts[0], parts[1], parts[2], parts[3]
            raw = f"{user}:{passwd}@{ip}:{port}"

    return f"{protocol}://{raw}"


def is_proxy_line(s: str) -> bool:
    """Determine whether a line represents a proxy configuration."""
    raw = s.strip()
    if not raw:
        return False
    if raw.lower().startswith("proxy:"):
        return True
    if any(raw.lower().startswith(p) for p in ("http://", "https://", "socks4://", "socks5://")):
        return True
    # Match IPv4:Port or IPv4:Port:User:Pass
    if re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d+", raw):
        return True
    # Match user:pass@host:port
    if "@" in raw and re.search(r"@[\w\.\-]+:\d+", raw):
        return True
    return False


def parse_accounts_file(file_path: str) -> List[Dict[str, str]]:
    """Parse acc.txt supporting both 2-line (email:pass \n proxy:...) and 1-line formats."""
    accounts: List[Dict[str, str]] = []

    try:
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            lines = [line.strip() for line in f.readlines()]
    except Exception as exc:
        print(f"  [X] Failed to open accounts file {file_path}: {exc}")
        return accounts

    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        i += 1

        # Skip empty lines or comment lines
        if not line or line.startswith("#"):
            continue

        # Check if line contains an account email (@ sign)
        if "@" in line and not line.lower().startswith("proxy:"):
            next_line = lines[i] if i < n else ""
            if is_proxy_line(next_line):
                # LINE 1: ACCOUNT, LINE 2: PROXY
                if ":" in line:
                    email, pwd = line.split(":", 1)
                else:
                    email, pwd = line, ""  # Cookie login (no password needed)

                proxy = normalize_proxy_string(next_line)
                i += 1  # Consume proxy line
                accounts.append({
                    "email": email.strip(),
                    "password": pwd.strip(),
                    "proxy": proxy,
                })
                continue

            # SINGLE LINE FORMAT
            if ":" in line:
                email_match = re.match(r"^([^:]+@[^:]+):(.*)$", line)
                if email_match:
                    email = email_match.group(1).strip()
                    rem = email_match.group(2).strip()

                    # Find proxy protocol in remainder
                    proto_idx = re.search(r":(https?://|socks[45]://)", rem, re.IGNORECASE)
                    if proto_idx:
                        pwd = rem[: proto_idx.start()].strip()
                        proxy = normalize_proxy_string(rem[proto_idx.start() + 1 :].strip())
                        accounts.append({"email": email, "password": pwd, "proxy": proxy})
                        continue

                    # Match IP:Port in remainder e.g. pass:1.2.3.4:8080
                    ip_match = re.search(r":(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d+.*)$", rem)
                    if ip_match:
                        pwd = rem[: ip_match.start()].strip()
                        proxy = normalize_proxy_string(ip_match.group(1).strip())
                        accounts.append({"email": email, "password": pwd, "proxy": proxy})
                        continue

                    # Plain email:pass without proxy
                    accounts.append({"email": email, "password": rem, "proxy": ""})
                    continue

            # Email only (Cookie login on direct IP)
            accounts.append({"email": line.strip(), "password": "", "proxy": ""})

    return accounts


def test_proxy_live(proxy_url: str, timeout: int = 10) -> bool:
    """Perform real TCP/TLS handshake to Microsoft login.live.com:443 via proxy."""
    if not proxy_url:
        return False

    try:
        norm = normalize_proxy_string(proxy_url)
        parsed = urllib.parse.urlparse(norm)
        host = parsed.hostname
        port = parsed.port
        proto = parsed.scheme.lower()

        if not host or not port:
            return False

        # 1. SOCKS5 Handshake
        if "socks5" in proto:
            s = socket.create_connection((host, port), timeout=timeout)
            s.sendall(b"\x05\x01\x00")
            res = s.recv(2)
            if len(res) < 2 or res[0] != 5 or res[1] != 0:
                s.close()
                return False
            dest_host = b"login.live.com"
            req = b"\x05\x01\x00\x03" + bytes([len(dest_host)]) + dest_host + (443).to_bytes(2, "big")
            s.sendall(req)
            rep = s.recv(10)
            s.close()
            return len(rep) >= 2 and rep[1] == 0

        # 2. SOCKS4 Handshake
        if "socks4" in proto:
            s = socket.create_connection((host, port), timeout=timeout)
            req = b"\x04\x01" + (443).to_bytes(2, "big") + b"\x00\x00\x00\x01\x00login.live.com\x00"
            s.sendall(req)
            rep = s.recv(8)
            s.close()
            return len(rep) >= 2 and rep[1] == 0x5A

        # 3. HTTP/HTTPS CONNECT Handshake
        s = socket.create_connection((host, port), timeout=timeout)
        connect_req = (
            f"CONNECT login.live.com:443 HTTP/1.1\r\n"
            f"Host: login.live.com:443\r\n"
            f"Proxy-Connection: Keep-Alive\r\n"
        )
        if parsed.username and parsed.password:
            creds = f"{parsed.username}:{parsed.password}"
            import base64
            auth_b64 = base64.b64encode(creds.encode("utf-8")).decode("ascii")
            connect_req += f"Proxy-Authorization: Basic {auth_b64}\r\n"
        connect_req += "\r\n"

        s.sendall(connect_req.encode("ascii"))
        res = s.recv(100)
        s.close()
        return b"200" in res

    except Exception:
        return False
