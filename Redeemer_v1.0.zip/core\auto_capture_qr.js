const path = require('node:path');
const fs = require('node:fs');

// 1. Locate Patchright from available node_modules
let chromium;
try {
    chromium = require('patchright').chromium;
} catch {
    try {
        chromium = require(path.resolve(__dirname, '../node_modules/patchright')).chromium;
    } catch {
        chromium = require(path.resolve(__dirname, '../../node_modules/patchright')).chromium;
    }
}

const [,, email, sku, rawProxy, cookiesPath, headlessArg] = process.argv;
const isHeadless = headlessArg === 'false' ? false : true;

(async () => {
    let proxyCfg = undefined;
    if (rawProxy && rawProxy !== 'none' && rawProxy !== '') {
        const p = rawProxy.trim();
        if (p.includes('://') || p.includes('@')) {
            try {
                const urlWithProto = p.includes('://') ? p : `http://${p}`;
                const u = new URL(urlWithProto);
                proxyCfg = {
                    server: `${u.protocol}//${u.host}`,
                    ...(u.username ? { username: decodeURIComponent(u.username), password: decodeURIComponent(u.password) } : {})
                };
            } catch {}
        } else {
            const parts = p.split(':');
            if (parts.length === 4) {
                proxyCfg = {
                    server: `http://${parts[0]}:${parts[1]}`,
                    username: parts[2],
                    password: parts[3]
                };
            } else if (parts.length === 2) {
                proxyCfg = { server: `http://${parts[0]}:${parts[1]}` };
            } else {
                proxyCfg = { server: `http://${p}` };
            }
        }
    }

    const validCookies = [];
    if (cookiesPath && fs.existsSync(cookiesPath)) {
        const raw = fs.readFileSync(cookiesPath, 'utf8');
        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                for (const c of parsed) {
                    if (!c.name || !c.value) continue;
                    const d = (c.domain || '.bing.com').replace(/^\./, '');
                    if (c.name.startsWith('__Host-')) {
                        validCookies.push({ name: c.name, value: c.value, url: `https://${d}/`, secure: true });
                    } else {
                        validCookies.push({ name: c.name, value: c.value, domain: `.${d}`, path: c.path || '/', secure: c.secure ?? false });
                    }
                }
            } else if (typeof parsed === 'object') {
                for (const [k, v] of Object.entries(parsed)) {
                    validCookies.push({ name: k, value: String(v), domain: '.bing.com', path: '/' });
                    validCookies.push({ name: k, value: String(v), domain: '.live.com', path: '/' });
                }
            }
        } catch {
            for (const line of raw.split('\n')) {
                const parts = line.trim().split('\t');
                if (parts.length >= 7) {
                    const domain = parts[0].trim().replace(/^\./, '');
                    const pathStr = parts[2].trim() || '/';
                    const secure = parts[3].trim().toUpperCase() === 'TRUE';
                    const name = parts[5].trim();
                    const value = parts[6].trim();
                    if (!name || !value) continue;
                    if (!domain.includes('bing.com') && !domain.includes('live.com') && !domain.includes('microsoft.com') && !domain.includes('msn.com')) continue;
                    if (name.startsWith('__Host-')) {
                        validCookies.push({ name, value, url: `https://${domain}/`, secure: true });
                    } else {
                        validCookies.push({ name, value, domain: `.${domain}`, path: pathStr, secure });
                    }
                }
            }
        }
    }

    const browser = await chromium.launch({
        headless: isHeadless,
        ...(proxyCfg ? { proxy: proxyCfg } : {}),
        args: [
            '--force-webrtc-ip-handling-policy=disable_non_proxied_udp',
            '--enforce-webrtc-ip-permission-check',
            '--disable-blink-features=AutomationControlled',
            '--mute-audio',
            '--no-sandbox',
            '--disable-dev-shm-usage',
            '--disable-background-networking',
            ...(isHeadless ? ['--window-size=1920,1080'] : ['--start-maximized', '--window-position=0,0'])
        ]
    });

    try {
        const context = await browser.newContext({
            // Visible mode: viewport=null with --start-maximized fills display cleanly
            viewport: isHeadless ? { width: 1920, height: 1080 } : null,
            userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'
        });

        // Grant Geolocation permissions per domain
        await context.grantPermissions(['geolocation'], { origin: 'https://rewards.bing.com' }).catch(() => {});
        await context.grantPermissions(['geolocation'], { origin: 'https://www.bing.com' }).catch(() => {});

        if (validCookies.length > 0) {
            await context.addCookies(validCookies);
        }

        // Acquire Mobile OAuth Access Token from authenticated cookie session
        let accessToken = null;
        try {
            const authUrl = `https://login.live.com/oauth20_authorize.srf?response_type=code&client_id=0000000040170455&redirect_uri=https%3A%2F%2Flogin.live.com%2Foauth20_desktop.srf&scope=service%3A%3Aprod.rewardsplatform.microsoft.com%3A%3AMBI_SSL&access_type=offline_access&login_hint=${encodeURIComponent(email)}`;
            const res = await context.request.get(authUrl, { maxRedirects: 20, timeout: 20000 });
            const m = res.url().match(/[?&]code=([^&#]+)/);
            if (m) {
                const tokenRes = await context.request.post('https://login.microsoftonline.com/consumers/oauth2/v2.0/token', {
                    form: {
                        grant_type: 'authorization_code',
                        client_id: '0000000040170455',
                        code: decodeURIComponent(m[1]),
                        redirect_uri: 'https://login.live.com/oauth20_desktop.srf',
                        scope: 'service::prod.rewardsplatform.microsoft.com::MBI_SSL'
                    },
                    timeout: 20000
                });
                const tokenData = await tokenRes.json();
                if (tokenData.access_token) {
                    accessToken = tokenData.access_token;
                    process.stdout.write(`__ACCESS_TOKEN__:${accessToken}\n`);
                }
            }
        } catch {}

        const page = await context.newPage();
        let capturedQr = null;
        let isOrderCompleted = false;

        page.on('request', req => {
            const u = req.url();
            if (!capturedQr && u.includes('/qr?data=') && (u.includes('rewards_secret') || u.includes('SappApp') || u.includes('adjust'))) {
                capturedQr = u;
                process.stdout.write(`__CAPTURED_QR__:${capturedQr}\n`);
            }
        });

        let targetUrl = `https://rewards.bing.com/redeem/sku/${sku}`;
        if (sku.startsWith('http://') || sku.startsWith('https://')) {
            targetUrl = sku;
        } else if (sku.startsWith('/')) {
            targetUrl = `https://rewards.bing.com${sku}`;
        } else if (sku.startsWith('sku/')) {
            targetUrl = `https://rewards.bing.com/redeem/${sku}`;
        }

        // 1. Navigate to target reward page
        await page.goto(targetUrl, { waitUntil: 'domcontentloaded', timeout: 35000 }).catch(() => {});
        await page.waitForTimeout(3000);

        // Check if item is Out of Stock / Restocking or CTA button is disabled
        const isOutOfStock = await page.evaluate(() => {
            const bodyText = (document.body.innerText || '').toLowerCase();
            const hasRestockText = bodyText.includes('restocking') || 
                                   bodyText.includes('back soon') || 
                                   bodyText.includes('out of stock') ||
                                   bodyText.includes('temporarily out of stock') ||
                                   bodyText.includes('hết hàng') ||
                                   bodyText.includes('nicht vorrätig') ||
                                   bodyText.includes('rupture de stock') ||
                                   bodyText.includes('agotado') ||
                                   bodyText.includes('esaurito');

            const allButtons = Array.from(document.querySelectorAll('button'));
            const brandBtn = allButtons.find(b => {
                const t = (b.innerText || '').toLowerCase();
                const c = b.className || '';
                return (t.includes('redeem now') || t.includes('đổi ngay') || t.includes('jetzt einlösen') || t.includes('utiliser') || t.includes('canjear') || t.includes('riscatta') || t.includes('今すぐ引き換える') || t.includes('立即兑换') || c.includes('BrandRest') || c.includes('bgCtrlBrand')) && !t.includes('cancel');
            });

            const isBtnDisabled = brandBtn ? (brandBtn.disabled || brandBtn.getAttribute('aria-disabled') === 'true' || brandBtn.classList.contains('disabled')) : false;

            return hasRestockText || (brandBtn && isBtnDisabled);
        });

        if (isOutOfStock) {
            process.stdout.write('__OUT_OF_STOCK__\n');
            await page.waitForTimeout(1000);
            await browser.close();
            process.exit(0);
        }

        // 2. Click "Redeem now" (Brand CTA) to open Step 1 modal
        await page.evaluate(() => {
            const allButtons = Array.from(document.querySelectorAll('button'));
            const brandBtn = allButtons.find(b => {
                const t = (b.innerText || '').toLowerCase();
                const c = b.className || '';
                return (t.includes('redeem now') || t.includes('đổi ngay') || t.includes('jetzt einlösen') || t.includes('utiliser') || t.includes('canjear') || t.includes('riscatta') || t.includes('今すぐ引き換える') || t.includes('立即兑换') || c.includes('BrandRest') || c.includes('bgCtrlBrand')) && !t.includes('cancel');
            });
            if (brandBtn) brandBtn.click();
        });

        await page.waitForTimeout(2500); // Await modal display

        // 3. Handle Turnstile & wait for Next button in Step 1 modal to enable
        let nextClicked = false;
        for (let sec = 1; sec <= 35; sec++) {
            if (isOrderCompleted) break;

            // Click Cloudflare checkbox if present inside iframe
            try {
                for (const f of page.frames()) {
                    if (f.url().includes('challenges.cloudflare.com')) {
                        const cb = await f.$('input[type="checkbox"], #challenge-stage, .ctp-checkbox-label').catch(() => null);
                        if (cb) await cb.click().catch(() => {});
                    }
                }
            } catch {}

            // Check if Next button in modal is enabled
            const nextReady = await page.evaluate(() => {
                const modal = document.querySelector('[role="dialog"], [aria-modal="true"], section[class*="outline-0"], div[class*="modal"]');
                if (!modal) return false;

                const btns = Array.from(modal.querySelectorAll('button'));
                const nextBtn = btns.find(b => {
                    const t = (b.innerText || '').toLowerCase();
                    return t.includes('next') || t.includes('tiếp theo') || t.includes('tiếp tục') || t.includes('weiter') || t.includes('suivant') || t.includes('siguiente') || t.includes('avanti') || t.includes('次へ') || t.includes('下一步');
                });
                if (!nextBtn) return false;

                const isDisabled = nextBtn.disabled ||
                                   nextBtn.getAttribute('data-disabled') === 'true' ||
                                   nextBtn.getAttribute('aria-disabled') === 'true';
                return !isDisabled;
            });

            if (nextReady) {
                // Wait 2 seconds for Turnstile token to settle into DOM
                await page.waitForTimeout(2000);

                // Click Next button to transition to Step 2 (QR & verification)
                await page.evaluate(() => {
                    const modal = document.querySelector('[role="dialog"], [aria-modal="true"], section[class*="outline-0"], div[class*="modal"]');
                    if (!modal) return;
                    const btns = Array.from(modal.querySelectorAll('button'));
                    const nextBtn = btns.find(b => {
                        const t = (b.innerText || '').toLowerCase();
                        return t.includes('next') || t.includes('tiếp theo') || t.includes('tiếp tục') || t.includes('weiter') || t.includes('suivant') || t.includes('siguiente') || t.includes('avanti') || t.includes('次へ') || t.includes('下一步');
                    });
                    if (nextBtn) nextBtn.click();
                });

                nextClicked = true;
                break;
            }

            await page.waitForTimeout(1000);
        }

        // 4. AFTER NEXT CLICK: AWAIT STEP 2 (VERIFY YOUR ACCOUNT MODAL)
        await page.waitForTimeout(2500);

        let capturedCode = null;
        let capturedLink = null;

        // Scan for QR image, 6-character captcha image, and direct verification link
        for (let wait = 1; wait <= 18; wait++) {
            if (isOrderCompleted) break;

            const screenData = await page.evaluate(() => {
                const modal = document.querySelector('[role="dialog"], [aria-modal="true"], section[class*="outline-0"], div[class*="modal"]');
                const root = modal || document;
                const text = root.innerText || '';

                // Search direct link 'verify your account here'
                const links = Array.from(root.querySelectorAll('a'));
                const verifyLink = links.find(a => (a.href || '').includes('rewards_secret') || (a.href || '').includes('SappApp') || (a.innerText || '').toLowerCase().includes('verify your account'));

                // Search QR image and 6-char captcha image
                const imgs = Array.from(root.querySelectorAll('img'));
                const qrImg = imgs.find(i => (i.src || '').includes('/qr?data=') || (i.alt || '').toLowerCase().includes('qr'));
                const codeImg = imgs.find(i => {
                    const a = (i.alt || '').toLowerCase();
                    const s = (i.src || '');
                    return a.includes('image verification code') || a.includes('verification code') || s.startsWith('data:image');
                });

                return {
                    linkHref: verifyLink ? verifyLink.href : '',
                    qrSrc: qrImg ? qrImg.src : '',
                    codeBase64: codeImg ? codeImg.src : '',
                    text: text
                };
            });

            if (screenData.linkHref && !capturedLink) {
                capturedLink = screenData.linkHref;
                process.stdout.write(`__CAPTURED_LINK__:${screenData.linkHref}\n`);
            }
            if (screenData.qrSrc && !capturedQr) {
                capturedQr = screenData.qrSrc;
                process.stdout.write(`__CAPTURED_QR__:${screenData.qrSrc}\n`);
            }

            if (screenData.codeBase64 && !capturedCode) {
                capturedCode = screenData.codeBase64;
                process.stdout.write(`__CAPTURED_CODE__:${screenData.codeBase64}\n`);
            }

            if ((capturedQr || capturedLink) && capturedCode) {
                break;
            }
            if ((capturedQr || capturedLink) && wait >= 8) {
                break;
            }
            await page.waitForTimeout(1000);
        }

        process.stdout.write('__STEP2_READY__\n');

        // 5. MONITOR CONFIRMATION & ORDER HISTORY (UP TO 120 SECONDS)
        let nextClickedInStep2 = false;

        for (let waitSec = 1; waitSec <= 120; waitSec++) {
            if (isOrderCompleted) break;

            if (!nextClickedInStep2) {
                // Check if Next button in Step 2 modal is unlocked
                const clickedNext = await page.evaluate(() => {
                    const modal = document.querySelector('[role="dialog"], [aria-modal="true"], section[class*="outline-0"], div[class*="modal"]');
                    if (!modal) return false;
                    const btns = Array.from(modal.querySelectorAll('button'));
                    const nextBtn = btns.find(b => {
                        const t = (b.innerText || '').toLowerCase();
                        return (t.includes('next') || t.includes('tiếp tục') || t.includes('tiếp theo') || t.includes('weiter') || t.includes('suivant') || t.includes('siguiente') || t.includes('avanti') || t.includes('次へ') || t.includes('下一步')) && !t.includes('cancel');
                    });
                    if (nextBtn && !nextBtn.disabled && nextBtn.getAttribute('data-disabled') !== 'true' && nextBtn.getAttribute('aria-disabled') !== 'true') {
                        nextBtn.click();
                        return true;
                    }
                    return false;
                }).catch(() => false);

                if (clickedNext) {
                    nextClickedInStep2 = true;
                    process.stdout.write('__STEP2_NEXT_CLICKED__\n');
                    await page.waitForTimeout(2000);
                }
            } else {
                // Step 2 Next was clicked: monitor for confirmation or order history navigation
                const confirmationState = await page.evaluate(() => {
                    const currentUrl = (window.location.href || '').toLowerCase();
                    const bodyText = (document.body ? document.body.innerText : '').toLowerCase();

                    // 1. Navigation to orderhistory
                    if (currentUrl.includes('/redeem/orderhistory')) {
                        return { confirmed: true, reason: 'URL navigated to orderhistory' };
                    }

                    // 2. Order confirmation text on screen
                    const hasConfirmText = bodyText.includes('your order is on the way') ||
                                           bodyText.includes('order confirmed') ||
                                           bodyText.includes('order no.') ||
                                           bodyText.includes('ihre bestellung ist unterwegs') ||
                                           bodyText.includes('votre commande est en cours') ||
                                           bodyText.includes('su pedido está en camino') ||
                                           bodyText.includes('il tuo ordine è in arrivo') ||
                                           bodyText.includes('đơn hàng của bạn đang trên đường gửi');

                    if (hasConfirmText) {
                        return { confirmed: true, reason: 'Order confirmed text' };
                    }

                    // 3. If final Place order / Confirm order button exists, click it
                    const btns = Array.from(document.querySelectorAll('button'));
                    const confirmBtn = btns.find(b => {
                        const t = (b.innerText || '').toLowerCase();
                        return (t.includes('confirm') || t.includes('place order') || t.includes('bestellung aufgeben') || t.includes('confirmer') || t.includes('confirmar') || t.includes('conferma') || t.includes('xác nhận') || t.includes('注文を確定') || t.includes('确认订单')) && !t.includes('cancel');
                    });
                    if (confirmBtn && !confirmBtn.disabled) {
                        confirmBtn.click();
                        return { clickedConfirm: true };
                    }

                    return { confirmed: false };
                }).catch(() => ({ confirmed: false }));

                if (confirmationState.confirmed) {
                    isOrderCompleted = true;
                    process.stdout.write('__NAVIGATING_TO_ORDER_HISTORY__\n');

                    // Hold browser for 3 seconds on confirmation screen
                    await page.waitForTimeout(3000);

                    // Navigate to Order History
                    await page.goto('https://rewards.bing.com/redeem/orderhistory', { waitUntil: 'domcontentloaded', timeout: 25000 }).catch(() => {});
                    await page.waitForTimeout(3000);

                    // Extract detailed order information (Code, PIN, Link, Status, OrderId)
                    const orderData = await page.evaluate(async () => {
                        const btns = Array.from(document.querySelectorAll('button'));
                        const viewDetailBtn = btns.find(b => {
                            const t = (b.innerText || '').toLowerCase();
                            return t.includes('view detail') || t.includes('order details') || t.includes('details anzeigen') || t.includes('afficher les détails') || t.includes('ver detalles') || t.includes('visualizza dettagli') || t.includes('xem chi tiết') || t.includes('詳細を表示') || t.includes('查看详情');
                        });

                        let foundCode = 'None';
                        let foundLink = 'None';
                        let foundOrderId = 'None';
                        let foundStatus = 'UNKNOWN';
                        let dialogSnippet = '';

                        if (viewDetailBtn) {
                            viewDetailBtn.click();
                            await new Promise(r => setTimeout(r, 2000));
                            const dialog = document.querySelector('[role="dialog"], [aria-modal="true"]');
                            if (dialog) {
                                const text = dialog.innerText || '';
                                dialogSnippet = text;
                                const mId = text.match(/Order\s+no\.\s+([a-f0-9\-]{8,})/i) ||
                                            text.match(/([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})/i);
                                if (mId) foundOrderId = mId[1];

                                const inputs = Array.from(dialog.querySelectorAll('input'));
                                for (const inp of inputs) {
                                    if (inp.value && inp.value.length >= 6 && inp.value.length <= 40) {
                                        foundCode = inp.value.trim();
                                        break;
                                    }
                                }

                                const links = Array.from(dialog.querySelectorAll('a'));
                                const claimLink = links.find(a => {
                                    const h = (a.href || '').toLowerCase();
                                    return h.includes('claim') || h.includes('gift') || h.includes('egift') || h.includes('voucher') || h.includes('redeem');
                                });
                                if (claimLink) foundLink = claimLink.href;

                                const lowerD = text.toLowerCase();
                                if (foundCode !== 'None' || foundLink !== 'None' || lowerD.includes('shipped') || lowerD.includes('thank you')) {
                                    foundStatus = 'SUCCESS_INSTANT';
                                } else if (lowerD.includes('pending') || lowerD.includes('processing') || lowerD.includes('24 hours') || lowerD.includes('đang xử lý')) {
                                    foundStatus = 'SUCCESS_PENDING';
                                }
                            }
                        }

                        if (foundOrderId === 'None') {
                            const bodyText = document.body ? document.body.innerText : '';
                            const mId = bodyText.match(/Order\s+no\.\s+([a-f0-9\-]{8,})/i);
                            if (mId) foundOrderId = mId[1];
                        }

                        return {
                            orderId: foundOrderId,
                            status: foundStatus,
                            code: foundCode,
                            link: foundLink,
                            dialogSnippet: dialogSnippet.slice(0, 300)
                        };
                    }).catch(() => ({
                        orderId: 'None',
                        status: 'UNKNOWN',
                        code: 'None',
                        link: 'None'
                    }));

                    process.stdout.write('__ORDER_RESULT__:' + JSON.stringify(orderData) + '\n');
                    process.stdout.write('__ORDER_PLACED_SUCCESS__\n');

                    // Hold browser open for 4 seconds so the user can see code and order details on screen
                    await page.waitForTimeout(4000);
                    break;
                }
            }

            await page.waitForTimeout(1000);
        }

        if (!capturedQr) {
            process.stdout.write('__CAPTURED_QR__:TIMEOUT\n');
        }
    } finally {
        await browser.close().catch(() => {});
    }
})();
