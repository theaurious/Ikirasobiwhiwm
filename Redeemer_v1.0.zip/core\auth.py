#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Direct HTTP OAuth login module (100% browserless) conforming to modern OAuth protocols."""

import http.cookiejar
import json
import re
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from core.crypto import get_random_sapphire_ua
from core.proxy import normalize_proxy_string

# Authoritative Microsoft Client IDs
CLIENT_ID_OFFICE_DESKTOP = "0000000048170EF2"
CLIENT_ID_BING_ANDROID = "0000000040170455"


class DirectSession:
    """HTTP session managing cookies and proxies via Python standard library."""

    def __init__(self, proxy_url: str = "", user_agent: Optional[str] = None):
        self.proxy_url = normalize_proxy_string(proxy_url) if proxy_url else ""
        self.user_agent = user_agent or get_random_sapphire_ua()
        self.cookie_jar = http.cookiejar.CookieJar()

        handlers = [urllib.request.HTTPCookieProcessor(self.cookie_jar)]
        if self.proxy_url:
            handlers.append(
                urllib.request.ProxyHandler({
                    "http": self.proxy_url,
                    "https": self.proxy_url,
                })
            )

        self.opener = urllib.request.build_opener(*handlers)

    def request(
        self,
        method: str,
        url: str,
        data: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: int = 15,
    ) -> Tuple[int, str, Dict[str, str]]:
        """Sends an HTTP request and returns (status_code, response_text, response_headers)."""
        req_headers = {
            "User-Agent": self.user_agent,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
        }
        if headers:
            req_headers.update(headers)

        encoded_data = None
        if data is not None:
            if isinstance(data, dict):
                encoded_data = urllib.parse.urlencode(data).encode("utf-8")
                if "Content-Type" not in req_headers:
                    req_headers["Content-Type"] = "application/x-www-form-urlencoded"
            elif isinstance(data, (bytes, bytearray)):
                encoded_data = bytes(data)

        req = urllib.request.Request(url, data=encoded_data, headers=req_headers, method=method.upper())

        try:
            with self.opener.open(req, timeout=timeout) as resp:
                status = resp.status
                body = resp.read().decode("utf-8", errors="replace")
                resp_headers = dict(resp.headers)
                return status, body, resp_headers
        except urllib.error.HTTPError as err:
            status = err.code
            body = err.read().decode("utf-8", errors="replace")
            resp_headers = dict(err.headers)
            return status, body, resp_headers
        except Exception as exc:
            raise RuntimeError(f"Network error via proxy ({self.proxy_url}): {exc}")

    def get_cookies_dict(self) -> Dict[str, str]:
        """Extracts existing cookies from the session."""
        return {c.name: c.value for c in self.cookie_jar}

    def set_cookies_dict(self, cookies: Dict[str, str], domain: str = ".live.com") -> None:
        """Injects cookies into the session cookie jar."""
        for k, v in cookies.items():
            ck = http.cookiejar.Cookie(
                version=0,
                name=k,
                value=v,
                port=None,
                port_specified=False,
                domain=domain,
                domain_specified=True,
                domain_initial_dot=True,
                path="/",
                path_specified=True,
                secure=True,
                expires=None,
                discard=False,
                comment=None,
                comment_url=None,
                rest={"HttpOnly": None},
            )
            self.cookie_jar.set_cookie(ck)


def extract_ppft(html: str) -> Optional[str]:
    """Extracts PPFT security token from Microsoft login page."""
    m = re.search(r'name=["\']PPFT["\'][^>]*value=["\']([^"\']+)["\']', html, re.I)
    if not m:
        m = re.search(r'value=["\']([^"\']+)["\'][^>]*name=["\']PPFT["\']', html, re.I)
    if not m:
        m = re.search(r'sFTTag:\s*["\'](.*?)value=\\"(.*?)\\"', html, re.I)
        if m:
            return m.group(2)
    return m.group(1) if m else None


def parse_cookie_content(text: str) -> Dict[str, str]:
    """Parses various cookie storage formats (JSON Array, JSON Dict, Netscape, Raw String)."""
    text = text.strip()
    if not text:
        return {}

    # 1. JSON format
    if (text.startswith("[") and text.endswith("]")) or (text.startswith("{") and text.endswith("}")):
        try:
            data = json.loads(text)
            # JSON Array: [{"name": "...", "value": "..."}, ...]
            if isinstance(data, list):
                out = {}
                for item in data:
                    if isinstance(item, dict) and "name" in item and "value" in item:
                        out[str(item["name"])] = str(item["value"])
                if out:
                    return out
            # JSON Dict: {"ANON": "...", "WLSSC": "..."}
            elif isinstance(data, dict):
                return {str(k): str(v) for k, v in data.items()}
        except Exception:
            pass

    # 2. Netscape format (tab-separated)
    if "\t" in text:
        out = {}
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split("\t")
            if len(parts) >= 7:
                name = parts[5].strip()
                val = parts[6].strip()
                if name:
                    out[name] = val
        if out:
            return out

    # 3. Raw String format (name=value; name2=value2;)
    out = {}
    for part in text.split(";"):
        part = part.strip()
        if "=" in part:
            k, v = part.split("=", 1)
            k = k.strip()
            v = v.strip()
            if k:
                out[k] = v
    return out


def save_cookies_file(cookies_dir: Path, email: str, cookies: Dict[str, str]) -> Path:
    """Saves session cookies to cookies/{clean_email}.json."""
    cookies_dir.mkdir(parents=True, exist_ok=True)
    clean_name = re.sub(r"[^a-zA-Z0-9_.-]", "_", email.lower())
    path = cookies_dir / f"{clean_name}.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cookies, f, indent=2)
    return path


def load_cookies_into_session(session: DirectSession, cookies_dir: Path, email: str) -> bool:
    """Loads cookies into DirectSession, preserving critical domains (.bing.com, .live.com, .microsoft.com)."""
    clean_name = re.sub(r"[^a-zA-Z0-9_.-]", "_", email.lower())
    candidates = [
        cookies_dir / f"{clean_name}.txt",
        cookies_dir / f"{email}.txt",
        cookies_dir / f"{clean_name}.json",
        cookies_dir / f"{email}.json",
    ]
    loaded_count = 0
    for p in candidates:
        if not p.exists():
            continue
        try:
            with open(p, "r", encoding="utf-8", errors="replace") as f:
                content = f.read().strip()
            if not content:
                continue

            # 1. Netscape format
            if "\t" in content:
                for line in content.splitlines():
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    parts = line.split("\t")
                    if len(parts) >= 7:
                        dom, _, path, sec, exp, name, val = parts[:7]
                        ck = http.cookiejar.Cookie(
                            version=0,
                            name=name.strip(),
                            value=val.strip(),
                            port=None,
                            port_specified=False,
                            domain=dom.strip(),
                            domain_specified=True,
                            domain_initial_dot=dom.strip().startswith("."),
                            path=path.strip() or "/",
                            path_specified=True,
                            secure=sec.strip().upper() == "TRUE",
                            expires=int(exp) if exp.isdigit() else None,
                            discard=False,
                            comment=None,
                            comment_url=None,
                            rest={"HttpOnly": None},
                        )
                        session.cookie_jar.set_cookie(ck)
                        loaded_count += 1
                if loaded_count > 0:
                    return True

            # 2. JSON format
            if (content.startswith("[") and content.endswith("]")) or (content.startswith("{") and content.endswith("}")):
                data = json.loads(content)
                if isinstance(data, list):
                    for item in data:
                        if isinstance(item, dict) and "name" in item and "value" in item:
                            c_dom = str(item.get("domain", ".live.com")).strip()
                            c_path = str(item.get("path", "/")).strip()
                            c_sec = bool(item.get("secure", True))
                            ck = http.cookiejar.Cookie(
                                version=0,
                                name=str(item["name"]).strip(),
                                value=str(item["value"]).strip(),
                                port=None,
                                port_specified=False,
                                domain=c_dom,
                                domain_specified=True,
                                domain_initial_dot=c_dom.startswith("."),
                                path=c_path,
                                path_specified=True,
                                secure=c_sec,
                                expires=None,
                                discard=False,
                                comment=None,
                                comment_url=None,
                                rest={"HttpOnly": None},
                            )
                            session.cookie_jar.set_cookie(ck)
                            loaded_count += 1
                    if loaded_count > 0:
                        return True
                elif isinstance(data, dict):
                    # Dict {"name": "val"}: populate all 3 domains
                    for k, v in data.items():
                        for dom in (".live.com", ".bing.com", ".microsoft.com"):
                            ck = http.cookiejar.Cookie(
                                version=0,
                                name=str(k).strip(),
                                value=str(v).strip(),
                                port=None,
                                port_specified=False,
                                domain=dom,
                                domain_specified=True,
                                domain_initial_dot=True,
                                path="/",
                                path_specified=True,
                                secure=True,
                                expires=None,
                                discard=False,
                                comment=None,
                                comment_url=None,
                                rest={"HttpOnly": None},
                            )
                            session.cookie_jar.set_cookie(ck)
                        loaded_count += 1
                    if loaded_count > 0:
                        return True

            # 3. Raw String format
            raw_parsed = parse_cookie_content(content)
            if raw_parsed:
                for k, v in raw_parsed.items():
                    for dom in (".live.com", ".bing.com", ".microsoft.com"):
                        ck = http.cookiejar.Cookie(
                            version=0,
                            name=str(k).strip(),
                            value=str(v).strip(),
                            port=None,
                            port_specified=False,
                            domain=dom,
                            domain_specified=True,
                            domain_initial_dot=True,
                            path="/",
                            path_specified=True,
                            secure=True,
                            expires=None,
                            discard=False,
                            comment=None,
                            comment_url=None,
                            rest={"HttpOnly": None},
                        )
                        session.cookie_jar.set_cookie(ck)
                    loaded_count += 1
                if loaded_count > 0:
                    return True

        except Exception:
            continue
    return loaded_count > 0


def load_cookies_file(cookies_dir: Path, email: str) -> Optional[Dict[str, str]]:
    """Loads cookies from .txt or .json files in cookies directory."""
    clean_name = re.sub(r"[^a-zA-Z0-9_.-]", "_", email.lower())
    candidates = [
        cookies_dir / f"{clean_name}.json",
        cookies_dir / f"{clean_name}.txt",
        cookies_dir / f"{email}.json",
        cookies_dir / f"{email}.txt",
    ]
    for p in candidates:
        if p.exists():
            try:
                with open(p, "r", encoding="utf-8", errors="replace") as f:
                    content = f.read()
                parsed = parse_cookie_content(content)
                if parsed:
                    return parsed
            except Exception:
                continue
    return None


def is_session_alive(session: DirectSession) -> bool:
    """Verifies if the session cookies are currently active using Bing Rewards API."""
    try:
        ts = int(time.time() * 1000)
        url = f"https://www.bing.com/rewards/panelflyout/getuserinfo?timestamp={ts}"
        status, body, _ = session.request(
            "GET",
            url,
            headers={
                "Accept": "application/json",
                "Referer": "https://www.bing.com/",
                "X-Requested-With": "XMLHttpRequest",
            },
            timeout=8,
        )
        if status == 200 and body and body.strip().startswith("{"):
            data = json.loads(body)
            user_info = data.get("userInfo", {})
            prof = user_info.get("profile", {})
            attrs = prof.get("attributes", {}) if isinstance(prof, dict) else {}
            if str(attrs.get("nonuser", "")).lower() == "true":
                return False
            return bool(user_info.get("isRewardsUser") or user_info.get("balance") is not None)
    except Exception:
        pass
    return False


def login_direct_oauth(
    email: str,
    password: str,
    proxy_url: str = "",
    timeout: int = 15,
) -> Tuple[str, Optional[DirectSession], Optional[str]]:
    """Logs in using Direct HTTP OAuth without a browser.

    Returns:
        (status, session, error_message)
        where status is one of:
          - "HIT": Login successful, valid session acquired.
          - "BAD": Incorrect password or account does not exist.
          - "RATE_LIMITED": Too many login attempts; IP or account temporarily throttled.
          - "2FA": Account requires 2-factor authentication or identity challenge.
          - "LOCKED": Account suspended or locked for violation/abuse.
    """
    session = DirectSession(proxy_url=proxy_url)

    # STEP 1: Fetch initial Microsoft login page to extract PPFT and session cookies
    login_init_url = (
        f"https://login.live.com/oauth20_authorize.srf"
        f"?client_id={CLIENT_ID_OFFICE_DESKTOP}"
        f"&redirect_uri=https://login.live.com/oauth20_desktop.srf"
        f"&response_type=token"
        f"&scope=service::prod.rewardsplatform.microsoft.com::MBI_SSL"
        f"&login_hint={urllib.parse.quote(email)}"
    )

    try:
        status, body, _ = session.request("GET", login_init_url, timeout=timeout)
    except Exception as exc:
        return "FAILED", None, f"Connection error during login initialization: {exc}"

    ppft = extract_ppft(body)
    if not ppft:
        # Fallback to base login.live.com form
        try:
            status, body, _ = session.request("GET", "https://login.live.com/", timeout=timeout)
            ppft = extract_ppft(body)
        except Exception:
            pass

    if not ppft:
        return "FAILED", None, "Unable to extract PPFT security token from Microsoft login page."

    # STEP 2: POST credentials
    post_url = "https://login.live.com/ppsecure/post.srf"
    post_payload = {
        "login": email,
        "passwd": password,
        "PPFT": ppft,
        "PPSX": "Passp",
        "NewUser": "1",
        "type": "11",
        "i13": "1",
    }

    try:
        post_status, post_body, post_headers = session.request(
            "POST",
            post_url,
            data=post_payload,
            headers={"Referer": login_init_url},
            timeout=timeout,
        )
    except Exception as exc:
        return "FAILED", None, f"Error submitting login credentials: {exc}"

    body_lower = post_body.lower()
    cookies = session.get_cookies_dict()

    # STEP 3: CLASSIFY RESPONSE

    # 1. Check Rate Limit / Throttling
    rate_limit_kws = [
        "you have tried too many times",
        "tried too many",
        "too many incorrect password",
        ",ac:null,",
        "please retry with a different device",
        "throttled",
    ]
    if any(kw in body_lower for kw in rate_limit_kws):
        return "RATE_LIMITED", None, "Too many login attempts. Microsoft has temporarily throttled login."

    # 2. Check Bad Credentials / Non-existent account
    bad_kws = [
        "password is incorrect",
        "doesn't exist",
        "account does not exist",
        "that password is not correct",
        "sign in with a different account",
    ]
    if any(kw in body_lower for kw in bad_kws):
        return "BAD", None, "Incorrect password or account does not exist."

    # 3. Check 2FA / Identity Verification / Suspended
    checkpoint_kws = [
        "verify your identity",
        "proofs/verify",
        "two-step verification",
        "help us protect your account",
        "/recover",
        "/abuse",
    ]
    if any(kw in body_lower for kw in checkpoint_kws):
        if "/abuse" in body_lower or "account is suspended" in body_lower:
            return "LOCKED", None, "Account locked or suspended by Microsoft."
        return "2FA", None, "2-step verification (2FA) or identity challenge required."

    # 4. Handle optional proofs/add screen (prompt to add phone/email)
    if "proofs/add" in body_lower or "ioptions=skip" in body_lower:
        try:
            skip_match = re.search(r'action=["\']([^"\']*cancel[^"\']*)["\']', post_body, re.I)
            skip_url = skip_match.group(1) if skip_match else "https://account.live.com/proofs/Add?mkt=en-US"
            session.request("GET", skip_url, timeout=8)
        except Exception:
            pass

    # 5. Handle privacy notice consent screen
    if "privacynotice" in body_lower:
        try:
            agree_ppft = extract_ppft(post_body)
            if agree_ppft:
                session.request(
                    "POST",
                    "https://account.live.com/privacynotice/Consent",
                    data={"PPFT": agree_ppft, "Accept": "Yes"},
                    timeout=8,
                )
        except Exception:
            pass

    # STEP 4: VERIFY SUCCESS (HIT)
    cookies_after = session.get_cookies_dict()
    has_auth = any(k in cookies_after for k in ("ANON", "WLSSC", "RPSSecAuth", "MSPOK"))
    if has_auth or post_status in (200, 302):
        return "HIT", session, None

    return "BAD", None, "Failed to acquire authenticated session cookies."
