#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Redemption Engine: gift card discovery, QR parsing, challenge verification, and order status extraction."""

import json
import re
import time
import urllib.parse
from typing import Any, Dict, List, Optional, Tuple

from core.auth import DirectSession
from core.crypto import build_encrypted_metadata, generate_totp

REWARDS_PLATFORM_ORIGIN = "https://prod.rewardsplatform.microsoft.com"


def get_profile_and_balance(session: DirectSession) -> Dict[str, Any]:
    """Retrieves Rewards points balance, country code, and RUID via Bing JSON API."""
    ts = int(time.time() * 1000)
    url = f"https://www.bing.com/rewards/panelflyout/getuserinfo?timestamp={ts}"
    status, body, _ = session.request(
        "GET",
        url,
        headers={
            "Accept": "application/json",
            "Referer": "https://www.bing.com/",
            "X-Requested-With": "XMLHttpRequest",
        },
        timeout=10,
    )

    result = {
        "balance": 0,
        "country": "Unknown",
        "ruid": "",
        "year": "Unknown",
        "isRewardsUser": False,
    }

    if status == 200 and body and body.strip().startswith("{"):
        try:
            data = json.loads(body)
            ui = data.get("userInfo", {})
            result["isRewardsUser"] = bool(ui.get("isRewardsUser", False))
            result["balance"] = int(ui.get("balance", 0))

            prof = ui.get("profile", {})
            attrs = prof.get("attributes", {}) if isinstance(prof, dict) else {}
            if "country" in attrs and attrs["country"]:
                result["country"] = str(attrs["country"]).strip().upper()
            elif ui.get("rewardsCountry"):
                result["country"] = str(ui.get("rewardsCountry")).strip().upper()

            if "created" in attrs and len(str(attrs["created"])) >= 4:
                result["year"] = str(attrs["created"])[:4]

            if isinstance(prof, dict) and prof.get("ruid"):
                result["ruid"] = str(prof["ruid"]).strip()
            elif ui.get("ruid"):
                result["ruid"] = str(ui.get("ruid")).strip()
            elif attrs.get("ruid"):
                result["ruid"] = str(attrs.get("ruid")).strip()
        except Exception:
            pass

    return result


def check_is_banned(session: DirectSession) -> Tuple[bool, str]:
    """Verifies whether the Microsoft Rewards account is genuinely suspended.

    Technical note:
    Microsoft Rewards Next.js JS bundles embed error templates across ALL pages,
    including for normal accounts. Do NOT regex match raw string templates across full HTML.
    Instead verify through:
      1. errorCode / errorMessage fields in official panelflyout API.
      2. Active <title> tag of page.
      3. Redirect location header.
    """
    # 1. Check panelflyout API
    try:
        ts = int(time.time() * 1000)
        url = f"https://www.bing.com/rewards/panelflyout/getuserinfo?timestamp={ts}"
        status, body, _ = session.request(
            "GET",
            url,
            headers={
                "Accept": "application/json",
                "Referer": "https://www.bing.com/",
                "X-Requested-With": "XMLHttpRequest",
            },
            timeout=8,
        )
        if status == 200 and body and body.strip().startswith("{"):
            data = json.loads(body)
            ui = data.get("userInfo", {})
            err_code = str(ui.get("errorCode", 0))
            err_msg = str(ui.get("errorMessage") or "")

            if err_code not in ("0", "None", ""):
                combined_err = f"{err_code} {err_msg}".lower()
                if "suspend" in combined_err or "banned" in combined_err or "closed" in combined_err:
                    return True, f"Account suspended by Microsoft Rewards ({err_msg or err_code})"
    except Exception:
        pass

    # 2. Check <title> and redirects on https://rewards.bing.com/
    try:
        status, body, headers = session.request("GET", "https://rewards.bing.com/", timeout=10)
        loc = headers.get("Location") or headers.get("location") or ""
        if "suspend" in loc.lower() or "issue=suspended" in loc.lower():
            return True, f"Server redirected to suspension page ({loc})"

        title_match = re.search(r"<title[^>]*>(.*?)</title>", body, re.I)
        if title_match:
            title_text = title_match.group(1).lower().strip()
            if "suspended" in title_text or "banned" in title_text or "account is closed" in title_text:
                return True, f"Account suspended by Microsoft Rewards (Title: {title_match.group(1).strip()})"
    except Exception:
        pass

    return False, ""


def fetch_live_account_giftcards(session: DirectSession, country: str = "US") -> List[Dict[str, Any]]:
    """Fetches real gift cards available in the user's country (filtering out sweepstakes & donations)."""
    c_lower = (country or "US").lower().strip()
    shop_urls = [
        f"https://rewards.bing.com/redeem/{c_lower}/shop",
        "https://rewards.bing.com/redeem/shop",
        "https://rewards.bing.com/redeem",
    ]

    body = ""
    for url in shop_urls:
        try:
            status, resp_body, _ = session.request("GET", url, timeout=12)
            if status == 200 and resp_body:
                body = resp_body
                break
        except Exception:
            continue

    if not body:
        return []

    cards: List[Dict[str, Any]] = []
    un = body.replace('\\"', '"')

    # Scan JSON blocks from Next.js SSR state
    item_blocks = re.findall(
        r'(\{\"id\":\s*\"000[^\"]+\"[^\}]*\"title\":\s*\"[^\"]+\"[^\}]*\"price\":\s*\d+[^\}]*\"href\":\s*\"[^\"]+\"[^\}]*\})',
        un,
    )

    # Multi-language sweepstakes and donation filter keywords
    blacklist_kws = [
        "sweepstake", "sweepstakes", "sweep", "raffle", "giveaway", "lottery",
        "draw", "win", "donate", "donation", "charity", "spende", "gewinnspiel",
        "lotterie", "don", "tirage au sort", "donación", "sorteo",
        "quay thưởng", "bốc thăm", "xổ số", "từ thiện", "quyên góp",
    ]

    seen_ids = set()
    for block in item_blocks:
        clean = re.sub(r':\"\$[^"]*\"', ':null', block)
        try:
            d = json.loads(clean)
            item_id = d.get("id")
            if not item_id or item_id in seen_ids:
                continue
            seen_ids.add(item_id)

            title = str(d.get("title", "")).strip()
            full_title = str(d.get("fullTitle", title)).strip()
            price = int(d.get("price", 0))
            href = str(d.get("href", "")).strip()
            is_disabled = bool(re.search(r'"isDisabled":\s*true', block, re.I)) or bool(d.get("isDisabled", False))

            if is_disabled or "/donate" in href or "/win" in href or any(kw in title.lower() for kw in blacklist_kws):
                continue

            cards.append({
                "id": item_id,
                "name": title,
                "fullTitle": full_title,
                "price": price,
                "href": href,
                "group": d.get("group", ""),
            })
        except Exception:
            continue

    return cards


def fetch_card_denominations(session: DirectSession, card: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Fetches point denomination tiers for the selected gift card."""
    href = card.get("href", "")
    if not href:
        return [{
            "id": card.get("id", ""),
            "label": card.get("fullTitle", card.get("name", "")),
            "points": card.get("price", 0),
            "is_out_of_stock": False,
        }]

    sku_url = "https://rewards.bing.com" + href if href.startswith("/") else href
    try:
        status, body, _ = session.request("GET", sku_url, timeout=12)
        if status != 200 or not body:
            return [{
                "id": card.get("id", ""),
                "label": card.get("fullTitle", card.get("name", "")),
                "points": card.get("price", 0),
                "is_out_of_stock": False,
            }]
    except Exception:
        return [{
            "id": card.get("id", ""),
            "label": card.get("fullTitle", card.get("name", "")),
            "points": card.get("price", 0),
            "is_out_of_stock": False,
        }]

    un = body.replace('\\"', '"')
    raw_blocks = re.findall(
        r'(\{"id":\s*"000[^\"]+\"[^\}]*\"denominationTitle\":\s*\"[^\"]+\"[^\}]*\})',
        un,
    )

    options: List[Dict[str, Any]] = []
    seen = set()
    for block in raw_blocks:
        m_id = re.search(r'"id":\s*"([^"]+)"', block)
        m_title = re.search(r'"denominationTitle":\s*"([^"]+)"', block)
        m_full = re.search(r'"fullTitle":\s*"([^"]+)"', block)
        m_price = re.search(r'"price":\s*(\d+)', block)
        is_disabled = bool(re.search(r'"isDisabled":\s*true', block, re.I))

        if not m_id:
            continue
        opt_id = m_id.group(1).strip()
        if opt_id in seen:
            continue
        seen.add(opt_id)

        label = (m_title.group(1) if m_title else (m_full.group(1) if m_full else card.get("name", ""))).strip()
        points = int(m_price.group(1)) if m_price else int(card.get("price", 0))

        options.append({
            "id": opt_id,
            "label": label,
            "points": points,
            "is_out_of_stock": is_disabled,
        })

    if not options:
        is_dis = False
        item_m = re.search(r'\{"id":\s*"000[^"]+"[^}]*"price":\s*\d+[^}]*\}', un)
        if item_m:
            is_dis = bool(re.search(r'"isDisabled":\s*true', item_m.group(0), re.I))
        elif "restocking" in un.lower() or "notavailable" in un.lower():
            is_dis = True

        options.append({
            "id": card.get("id", ""),
            "label": card.get("fullTitle", card.get("name", "")),
            "points": card.get("price", 0),
            "is_out_of_stock": is_dis,
        })

    return options


def find_target_reward_in_catalog(
    session: DirectSession,
    keyword: str,
    target_pts: int,
) -> Tuple[Optional[Dict[str, Any]], str]:
    """Searches for reward matching keyword and point value in account catalog."""
    try:
        status, body, _ = session.request(
            "GET",
            "https://rewards.bing.com/api/getuserinfo",
            headers={"Accept": "application/json", "Referer": "https://rewards.bing.com/"},
            timeout=10,
        )
        if status == 200 and body and body.strip().startswith("{"):
            data = json.loads(body)
            dashboard = data.get("dashboard", {})
            redeem_goal = dashboard.get("userStatus", {}).get("redeemGoal", {})

            # 1. Pinned Redeem Goal
            if redeem_goal and keyword.lower() in str(redeem_goal.get("title", "")).lower():
                return {
                    "title": redeem_goal.get("title", keyword),
                    "id": redeem_goal.get("id", ""),
                    "pointsCost": redeem_goal.get("pointPrice", target_pts),
                }, ""

            # 2. Promotions list
            promotions = dashboard.get("promotions", [])
            for p in promotions:
                title = str(p.get("title", ""))
                if keyword.lower() in title.lower():
                    return {
                        "title": title,
                        "id": p.get("id", ""),
                        "pointsCost": p.get("pointPrice", target_pts),
                    }, ""

    except Exception as exc:
        return None, f"Connection error scanning reward catalog: {exc}"

    return None, f"Reward matching '{keyword}' ({target_pts} pts) not found in account's catalog."


def parse_qr_url(input_str: str) -> Optional[Dict[str, Any]]:
    """Extracts rewardsSecret, rewardsPeriod, and captchaVersion from QR code URL or raw string."""
    if not input_str or not input_str.strip():
        return None

    raw = input_str.strip()

    if "data=" in raw:
        m = re.search(r'data=([^&]+)', raw)
        if m:
            raw = urllib.parse.unquote(m.group(1))

    unquoted = urllib.parse.unquote(raw)

    bag = {}
    for key in ("rewards_secret", "rewards_period", "captcha_version", "rewards_account"):
        m = re.search(rf'[\?&;]{key}=([^&#;\'"\s]+)', unquoted, re.I)
        if m:
            bag[key] = m.group(1).strip()

    if not bag.get("rewards_secret"):
        cleaned = re.sub(r'[^A-Za-z0-9+/=_-]', '', raw)
        if len(cleaned) >= 16:
            bag["rewards_secret"] = cleaned

    rewards_secret = bag.get("rewards_secret")
    if not rewards_secret:
        return None

    return {
        "rewardsSecret": rewards_secret,
        "rewardsPeriod": int(bag.get("rewards_period", 300)),
        "captchaVersion": bag.get("captcha_version", "v2"),
        "rewardsAccount": bag.get("rewards_account", "None"),
    }


def initiate_redemption_challenge(
    session: DirectSession,
    reward_item: Dict[str, Any],
) -> Tuple[str, Optional[Dict[str, Any]], Optional[bytes], str]:
    """Submits redemption request to Microsoft Next.js Server Action or initiates QR challenge.

    Returns:
        (status, qr_info, image_bytes, error_message)
        status: 'SUCCESS', 'INSTANT_SUCCESS', 'NEED_QR_PASTE', 'BANNED', 'FAILED'
    """
    sku = reward_item.get("id") or ""
    href = reward_item.get("href") or f"/redeem/sku/{sku}"
    item_url = f"https://rewards.bing.com{href}" if href.startswith("/") else href

    # 1. Invoke Next.js placeOrder Server Action
    action_headers = {
        "Next-Action": "40af3b131810f39d6d41c8b02c8ce94878b7c34ad4",
        "Content-Type": "text/plain;charset=UTF-8",
        "Accept": "text/x-component",
        "Referer": item_url,
        "Origin": "https://rewards.bing.com",
    }
    payload = [{"sku": sku, "appliedCoupons": []}]

    try:
        status, body, _ = session.request(
            "POST",
            item_url,
            data=json.dumps(payload).encode("utf-8"),
            headers=action_headers,
            timeout=15,
        )

        if status == 200 and body:
            order_m = re.search(r'"orderId":\s*"([^"$]+)"', body)
            if order_m and order_m.group(1):
                return "INSTANT_SUCCESS", {"orderId": order_m.group(1).strip()}, None, ""

            if "sapphireCaptchaDetails" in body and '"sapphireCaptchaDetails":"$undefined"' not in body:
                m_red = re.search(r'"redirectUrl":\s*"([^"]+)"', body)
                if m_red:
                    qr_info = parse_qr_url(m_red.group(1))
                    if qr_info:
                        img_bytes = None
                        m_img = re.search(r'"imageCodeBase64":\s*"([^"]+)"', body)
                        if m_img:
                            import base64
                            try:
                                img_bytes = base64.b64decode(m_img.group(1))
                            except Exception:
                                pass
                        return "SUCCESS", qr_info, img_bytes, ""

            if "E_BOT_REJECT" in body or "E_USER_QUARANTINED" in body or '"code":9' in body:
                return "BANNED", None, None, "Account flagged or suspended by Microsoft during redemption."

    except Exception:
        pass

    # 2. Browser interaction required for Turnstile / QR activation
    return "NEED_QR_PASTE", {"item_url": item_url, "sku": sku}, None, "Browser verification required to generate QR code."


# Microsoft Rewards Next.js Server Action Error Code Mapping
REWARDS_ERROR_MAP: Dict[int, str] = {
    1: "E_VALIDATION_ERROR (Invalid request data)",
    3: "E_MISSING_REQUEST_DATA (Missing request parameters)",
    9: "E_USER_SUSPENDED (Account suspended by Microsoft Rewards)",
    10: "E_USER_OPTOUT (Account opted out of Rewards)",
    11: "E_UNSUPPORTED_COUNTRY (Country not supported for this reward)",
    13: "E_TIMEOUT (Request timed out)",
    14: "E_THROTTLED (Rate limited, too many requests)",
    15: "E_API_ACCESS_DENIED (API access denied)",
    18: "E_UNAUTHORIZED_REQUEST (Unauthorized or cookie expired)",
    2002: "E_INSUFFICIENT_BALANCE (Insufficient points balance)",
    2003: "E_INVALID_SKU (Invalid or removed reward SKU)",
    2004: "E_ORDER_FAILURE (Server error creating order)",
    2005: "E_SOLVE_FAILURE (Captcha solve failed or expired)",
    2006: "E_CHALLENGE_FAILURE (Challenge creation failure)",
    2007: "E_CHALLENGE_FIRST (QR challenge required first)",
    2008: "E_SOLVE_FIRST (SMS phone verification required)",
    2009: "E_RISK_REJECT (Order rejected by Microsoft risk filter)",
    2010: "E_RISK_FAILURE (Risk assessment error)",
    2011: "E_RISK_REVIEW (Order held for manual review)",
    2013: "E_AnnualRedemptionLimitExceeded (Annual 3rd party limit exceeded)",
    2030: "E_BOT_REJECT (Bot or automation activity detected)",
    2031: "E_GEO_LOCATION_REJECT (Invalid location or blocked proxy IP)",
    2032: "E_FRAUD_REJECT (Fraud detection trigger)",
    2034: "E_USER_QUARANTINED (Account quarantined)",
    2035: "E_CAPTCHA_INVALID_REJECT (Incorrect 6-character captcha)",
    2037: "E_NO_CAPTCHA_TRIGGER (Cloudflare Turnstile verification required)",
    2042: "E_EXISTING_RISK_REVIEW (Existing order pending review)",
    2045: "E_ORDER_IN_PROGRESS (Order currently in progress)",
    2046: "E_RISK_APPROVED (Risk approved)",
    2055: "E_AnnualFirstPartyRedemptionLimitExceeded (Annual Microsoft limit exceeded)",
    2056: "E_SKU_OUTOFINVENTORY (Reward item is out of stock)",
}


def finalize_order(session: DirectSession, sku: str, href: str = "") -> Tuple[bool, str, Optional[str]]:
    """Finalizes order by submitting placeOrder Server Action with isSapphireCaptchaCompleted: True."""
    item_url = f"https://rewards.bing.com{href}" if href.startswith("/") else (href or f"https://rewards.bing.com/redeem/sku/{sku}")
    action_headers = {
        "Next-Action": "40af3b131810f39d6d41c8b02c8ce94878b7c34ad4",
        "Content-Type": "text/plain;charset=UTF-8",
        "Accept": "text/x-component",
        "Referer": item_url,
        "Origin": "https://rewards.bing.com",
    }
    payload = [{"sku": sku, "appliedCoupons": [], "isSapphireCaptchaCompleted": True}]

    try:
        status, body, _ = session.request(
            "POST",
            item_url,
            data=json.dumps(payload).encode("utf-8"),
            headers=action_headers,
            timeout=15,
        )
        if status == 200 and body:
            order_m = re.search(r'"orderId":\s*"([^"$]+)"', body)
            if order_m and order_m.group(1):
                return True, "Order confirmed successfully!", order_m.group(1).strip()
            if '"code":0' in body or "Success" in body:
                return True, "Order confirmed successfully!", None

            code_m = re.search(r'"code":\s*(\d+)', body)
            if code_m:
                err_code = int(code_m.group(1))
                err_desc = REWARDS_ERROR_MAP.get(err_code, f"Undefined error ({err_code})")
                raw_snippet = body.strip().replace("\n", " ")[:200]
                return False, f"Microsoft error [Code {err_code}: {err_desc}]. Raw: {raw_snippet}", None

            raw_snippet = body.strip().replace("\n", " ")[:200]
            return False, f"Server returned unknown response (HTTP {status}): {raw_snippet}", None

        raw_snippet = (body or "").strip().replace("\n", " ")[:200]
        return False, f"Server HTTP {status}: {raw_snippet}", None
    except Exception as exc:
        return False, f"Connection error finalizing order: {exc}", None


def verify_redemption_challenge(
    session: DirectSession,
    email: str,
    ruid: str,
    qr_info: Dict[str, Any],
    image_code: str,
    access_token: str = "",
    country: str = "US",
) -> Tuple[bool, str]:
    """Signs RSA 2048-bit + TOTP SHA-1 and verifies challenge with Bing Android API."""
    server_now_ms = int(time.time() * 1000)

    totp_code = generate_totp(
        secret_base32=qr_info["rewardsSecret"],
        period=int(qr_info.get("rewardsPeriod", 300)),
        digits=6,
        timestamp_ms=server_now_ms,
    )

    meta_encrypted = build_encrypted_metadata(email=email, ruid=ruid or email, timestamp_ms=server_now_ms)

    payload = {
        "code": totp_code,
        "meta": meta_encrypted,
        "scenario": "RedemptionV1" if qr_info.get("captchaVersion") == "v2" else "Redemption",
        "imageCode": image_code,
    }

    verify_url = f"{REWARDS_PLATFORM_ORIGIN}/dapi/me/captcha/verify"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-Rewards-Country": (country or "US").lower(),
        "X-Rewards-AppId": "5a81e9d1-0f77-4b72-8e0c-99e69e4f518e",
        "X-Rewards-IsMobile": "true",
    }
    if access_token:
        headers["Authorization"] = f"Bearer {access_token}"

    try:
        payload_bytes = json.dumps(payload).encode("utf-8")
        status, body, _ = session.request("POST", verify_url, data=payload_bytes, headers=headers, timeout=20)
        raw_resp = (body or "").strip().replace("\n", " ")[:300]
        if status in (200, 201):
            if "success" in raw_resp.lower() or "completed" in raw_resp.lower():
                return True, "Bing Android challenge verified successfully"
            return True, f"Bing Android accepted challenge (HTTP {status})"
        return False, f"Bing Android rejected challenge (HTTP {status}). Raw: {raw_resp}"
    except Exception as exc:
        return False, f"Connection error verifying challenge: {exc}"


def fetch_latest_order_status(session: DirectSession) -> Dict[str, Any]:
    """Queries order history to extract PIN/Code, Claim Link, or Pending status.

    Strict rule: Never assume or mock fake fallback data. If absent, explicitly set to 'None' or 'Unknown'.
    """
    order_info = {
        "status": "NONE",
        "title": "None",
        "code": "None",
        "link": "None",
        "orderId": "None",
        "points": "0",
        "date": "Unknown",
    }

    try:
        history_url = "https://rewards.bing.com/redeem/orderhistory"
        status, body, _ = session.request("GET", history_url, timeout=12)
        if status != 200 or not body:
            return order_info

        un = body.replace('\\"', '"')

        # 1. Match actual orders in Next.js state: "orderId":"...", "status":"..."
        order_matches = re.findall(r'"orderId":\s*"([a-f0-9\-]{8,})"[^}]*"status":\s*"([^"]+)"', un)
        if not order_matches:
            # Pattern match text: "Order no. <id>"
            text_ids = re.findall(r'Order\s+no\.\s+([a-f0-9\-]{8,})', un, re.I)
            if text_ids:
                order_matches = [(tid, "Pending") for tid in text_ids]

        if not order_matches:
            return order_info

        found_order_id, found_status = order_matches[0]

        # Extract order date
        order_date = "Unknown"
        pos = un.find(found_order_id)
        if pos != -1:
            snippet = un[max(0, pos - 300) : min(len(un), pos + 300)]
            d_m = re.search(r'(\d{1,2}/\d{1,2}/\d{4})', snippet)
            if d_m:
                order_date = d_m.group(1)

        order_info["orderId"] = found_order_id
        order_info["date"] = order_date

        # Extract PIN/Code and Link in the vicinity of this order
        if pos != -1:
            order_scope = un[max(0, pos - 500) : min(len(un), pos + 1000)]
            m_code = re.search(r'(?:pin|code)[\s\:]+([a-zA-Z0-9\-_]{6,30})', order_scope, re.I)
            if m_code:
                order_info["code"] = m_code.group(1).strip()

            m_link = re.search(r'href=["\'](https?://[^"\']*(?:claim|redeem|voucher|gift)[^"\']*)["\']', order_scope, re.I)
            if m_link:
                order_info["link"] = m_link.group(1).strip()

        st_lower = found_status.lower()
        if st_lower in ("in progress", "pending"):
            order_info["status"] = "SUCCESS_PENDING"
        elif st_lower in ("shipped", "completed") or order_info["code"] != "None" or order_info["link"] != "None":
            order_info["status"] = "SUCCESS_INSTANT"
        else:
            order_info["status"] = "SUCCESS_PENDING"

    except Exception:
        pass

    return order_info
