@echo off
chcp 65001 >nul
title Redeemer - Microsoft Rewards Auto Redeem Engine
cd /d "%~dp0"
python redeem.py
if %errorlevel% neq 0 (
    echo.
    echo [!] Process exited with code %errorlevel%.
    pause
)
