# REDEEMER — USER GUIDE

---

1. ACCOUNT FORMAT (acc.txt)
Add your accounts to acc.txt using the standard 2-line format:


email:password
proxy:http://user:pass@ip:port


*Examples:

#Acc1
user1@hotmail.com:Password123!
proxy:http://user1:pass1@103.187.4.82:50740

#Acc2
user2@outlook.com:Password456@
proxy:103.15.22.5:1080:user2:pass2

(If an account does not use a proxy, simply leave the proxy line empty).

---

2. config.json
headless:
  - `true`: Runs completely in the background without opening a browser window.
  - `false`: Opens the browser window so you can watch the tool work.
session: Automatically saves session state in the session file for faster future logins.
captcha: You can enter your Captcha solving API key in `api_key`.

---

3. COOKIE MANAGEMENT (cookies/)
* Save cookie files inside the cookies/ folder named as email.txt (e.g. cookies/user1@hotmail.com.txt).
* The tool automatically prioritizes valid cookies and logs in without needing a password.

---

4. RESULT DIRECTORY (Result/)
All results are automatically sorted into the `Result/` folder:
Result/success.txt: Successfully redeemed with instant PIN / Voucher code.
Result/pending.txt: Order placed, pending Microsoft 24-hour review.
Result/banned.txt: Account suspended by Microsoft Rewards.
Result/bad.txt: Incorrect password or missing credentials.
Result/need_verify.txt: Requires 2FA or phone verification.
Result/failed.txt: Failed due to insufficient points or network error.

---

## 5. HOW TO RUN
* Simply double-click redeem.py (or run python redeem.py in terminal).
