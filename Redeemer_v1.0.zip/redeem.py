#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""REDEEMER v1.0 — MICROSOFT REWARDS AUTOMATED REDEEM ENGINE (HYBRID STEALTH).

Core Rules:
1. Never hardcode fallback values for missing data.
2. If data is empty or missing, explicitly display "None" or "Unknown".
3. All network requests must strictly route through each account's dedicated proxy.
4. Correct sequence: Login first -> Query live balance & available gift cards -> Redeem.
"""

from __future__ import annotations

import datetime
import json
import os
import queue
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

# Enable ANSI escape processing in Windows console
os.system("")

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")


# Standard ANSI Color Palette
class C:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    WHITE = "\033[97m"
    GRAY = "\033[90m"


def log_info(msg: str) -> None:
    print(f"  {C.CYAN}✦{C.RESET} {msg}")


def log_success(msg: str) -> None:
    print(f"  {C.GREEN}✔ {msg}{C.RESET}")


def log_warn(msg: str) -> None:
    print(f"  {C.YELLOW}▲ {msg}{C.RESET}")


def log_error(msg: str) -> None:
    print(f"  {C.RED}✖ {msg}{C.RESET}")


ROOT_DIR = Path(__file__).resolve().parent
CONFIG_PATH = ROOT_DIR / "config.json"
ACCOUNTS_PATH = ROOT_DIR / "acc.txt"
if not ACCOUNTS_PATH.exists() and (ROOT_DIR / "accounts.txt").exists():
    ACCOUNTS_PATH = ROOT_DIR / "accounts.txt"
COOKIES_DIR = ROOT_DIR / "cookies"
CAPTCHAS_DIR = ROOT_DIR / "captchas"
RESULT_DIR = ROOT_DIR / "Result"

from core.auth import (
    DirectSession,
    is_session_alive,
    load_cookies_file,
    load_cookies_into_session,
    login_direct_oauth,
    parse_cookie_content,
    save_cookies_file,
)
from core.captcha import resolve_captcha_4tiers
from core.proxy import normalize_proxy_string, parse_accounts_file, test_proxy_live
from core.redeem_engine import (
    check_is_banned,
    fetch_card_denominations,
    fetch_latest_order_status,
    fetch_live_account_giftcards,
    finalize_order,
    get_profile_and_balance,
    initiate_redemption_challenge,
    parse_qr_url,
    verify_redemption_challenge,
)


def load_config() -> Dict[str, Any]:
    """Load config.json file."""
    if not CONFIG_PATH.exists():
        log_error(f"Configuration file {CONFIG_PATH.name} not found.")
        sys.exit(1)
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def append_result(filename: str, line: str) -> None:
    """Append a line to the specified file in Result/ folder."""
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    target = RESULT_DIR / filename
    with open(target, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def print_banner() -> None:
    """Display modern compact ASCII banner."""
    print(f"{C.CYAN}{C.BOLD}")
    print("  ╔══════════════════════════════════════════════════════════════════════╗")
    print("  ║           REDEEMER v1.0 — MICROSOFT REWARDS AUTO REDEEM              ║")
    print("  ║      [✦ Cloudflare Stealth  ✦ Multi-Step Bypass  ✦ Direct API]       ║")
    print("  ╚══════════════════════════════════════════════════════════════════════╝")
    print(f"{C.RESET}")


def discover_all_accounts(accounts_path: Path, cookies_dir: Path) -> List[Dict[str, Any]]:
    """Scan cookies/ folder first, then scan acc.txt."""
    txt_accounts = parse_accounts_file(str(accounts_path)) if accounts_path.exists() else []
    txt_lookup: Dict[str, Dict[str, str]] = {a["email"].lower(): a for a in txt_accounts}

    cookie_accounts: List[Dict[str, Any]] = []
    seen_emails = set()

    # 1. Scan cookies/ folder
    if cookies_dir.exists():
        for f in sorted(cookies_dir.iterdir(), key=lambda x: x.name.lower()):
            if f.is_file() and f.suffix.lower() in (".txt", ".json"):
                stem = f.stem.strip()
                if "@" in stem:
                    email_clean = stem
                    em_lower = email_clean.lower()
                    if em_lower in seen_emails:
                        continue
                    seen_emails.add(em_lower)

                    matched_txt = txt_lookup.get(em_lower, {})
                    pwd = matched_txt.get("password", "")
                    px = matched_txt.get("proxy", "")

                    cookie_accounts.append({
                        "email": email_clean,
                        "password": pwd,
                        "proxy": px,
                        "source": "cookie",
                        "cookie_file": f.name,
                    })

    # 2. Scan remaining accounts in acc.txt
    txt_only_accounts: List[Dict[str, Any]] = []
    for a in txt_accounts:
        em_lower = a["email"].lower()
        if em_lower not in seen_emails:
            seen_emails.add(em_lower)
            txt_only_accounts.append({
                "email": a["email"],
                "password": a["password"],
                "proxy": a["proxy"],
                "source": "txt",
                "cookie_file": None,
            })

    return cookie_accounts + txt_only_accounts


def auto_capture_qr_from_browser(
    email: str,
    sku: str,
    proxy: str,
    cookie_file_path: Path,
    headless: bool = True,
    session: Optional[DirectSession] = None,
    ruid: str = "",
    country: str = "US",
    config: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Automate Patchright browser to bypass Turnstile, capture verification link and monitor order completion."""
    result: Dict[str, Any] = {"status": "FAILED", "qr_url": None, "direct_link": None, "code": None}
    js_script = ROOT_DIR / "core" / "auto_capture_qr.js"
    if not js_script.exists():
        return result

    local_node = ROOT_DIR / "bin" / "node.exe"
    if not local_node.exists():
        local_node = ROOT_DIR / "node.exe"

    node_cmd = str(local_node) if local_node.exists() else (shutil.which("node") or "node")
    args = [
        node_cmd,
        str(js_script),
        email,
        sku,
        proxy or "none",
        str(cookie_file_path),
        "true" if headless else "false",
    ]

    try:
        proc = subprocess.Popen(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
        )

        line_queue: queue.Queue = queue.Queue()

        def stdout_reader():
            try:
                for line in iter(proc.stdout.readline, ""):
                    if line:
                        line_queue.put(line.strip())
            except Exception:
                pass

        reader_thread = threading.Thread(target=stdout_reader, daemon=True)
        reader_thread.start()

        has_verified = False
        start_time = time.time()
        max_wait_sec = 180

        while time.time() - start_time < max_wait_sec:
            if proc.poll() is not None and line_queue.empty():
                break

            try:
                line_str = line_queue.get(timeout=0.5)
            except queue.Empty:
                continue

            if not line_str:
                continue

            if line_str.startswith("__ACCESS_TOKEN__:"):
                tok = line_str[len("__ACCESS_TOKEN__:") :].strip()
                result["access_token"] = tok
                log_info("Mobile OAuth Access Token acquired.")

            elif line_str.startswith("__CAPTURED_LINK__:"):
                link = line_str[len("__CAPTURED_LINK__:") :].strip()
                result["direct_link"] = link
                log_success("Step 2 reached! Direct verification link captured.")
                print(f"  {C.CYAN}👉 Link: {link}{C.RESET}")

            elif line_str.startswith("__CAPTURED_QR__:"):
                qr_url = line_str[len("__CAPTURED_QR__:") :].strip()
                if qr_url != "TIMEOUT":
                    result["qr_url"] = qr_url
                    if not result.get("direct_link"):
                        log_success("Step 2 reached! QR challenge captured.")
                        print(f"  {C.CYAN}👉 QR URL: {qr_url}{C.RESET}")

            elif line_str.startswith("__CAPTURED_CODE__:"):
                code_data = line_str[len("__CAPTURED_CODE__:") :].strip()
                result["code"] = code_data
                log_info("Captcha image code captured from screen.")

            elif line_str == "__OUT_OF_STOCK__":
                result["status"] = "OUT_OF_STOCK"
                log_error("Gift card is OUT OF STOCK on Microsoft Rewards ('So popular we're restocking! Back soon').")
                break

            elif line_str == "__STEP2_NEXT_CLICKED__":
                log_info("Next button unlocked and clicked in browser! Waiting for final confirmation...")

            elif line_str == "__NAVIGATING_TO_ORDER_HISTORY__":
                log_info("Order placed! Keeping browser open for 3s, then checking Order History...")

            elif line_str.startswith("__ORDER_RESULT__:"):
                raw_json = line_str[len("__ORDER_RESULT__:") :].strip()
                try:
                    result["order_result"] = json.loads(raw_json)
                except Exception:
                    pass

            elif line_str in ("__STEP2_READY__",) or (result.get("qr_url") and result.get("code")):
                if not has_verified and session:
                    qr_target_url = result.get("direct_link") or result.get("qr_url")
                    parsed_qr = parse_qr_url(qr_target_url) if qr_target_url else None
                    if parsed_qr:
                        has_verified = True
                        result["qr_info"] = parsed_qr

                        # 1. Resolve image captcha if present
                        image_code = ""
                        if result.get("code"):
                            raw_b64 = result["code"]
                            if "base64," in raw_b64:
                                raw_b64 = raw_b64.split("base64,", 1)[1]
                            try:
                                import base64
                                img_bytes = base64.b64decode(raw_b64)
                                log_info("Solving image captcha automatically...")
                                image_code = resolve_captcha_4tiers(
                                    image_bytes=img_bytes,
                                    email=email,
                                    config=config or {},
                                    captchas_dir=CAPTCHAS_DIR,
                                )
                                log_success(f"Captcha solved: {C.BOLD}{image_code}{C.RESET}")
                                result["image_code"] = image_code
                            except Exception as e:
                                log_warn(f"Captcha solve error: {e}")

                        # 2. Submit Bing Android Challenge Verify API
                        log_info("Verifying Bing Android challenge (RSA-2048 + TOTP)...")
                        access_tok = result.get("access_token", "")
                        verified, v_msg = verify_redemption_challenge(
                            session=session,
                            email=email,
                            ruid=ruid,
                            qr_info=parsed_qr,
                            image_code=image_code,
                            access_token=access_tok,
                            country=country,
                        )

                        if verified:
                            log_success("Challenge verified on Microsoft Server! Unlocking browser button...")
                            result["verified"] = True
                        else:
                            log_warn(f"Verification response: {v_msg}")

            elif line_str == "__ORDER_PLACED_SUCCESS__":
                result["status"] = "SUCCESS"
                log_success("Order confirmed and completed on browser!")
                break

        try:
            proc.terminate()
        except Exception:
            pass

        return result
    except Exception as exc:
        log_error(f"Browser automation error: {exc}")
        return result


def main() -> None:
    print_banner()

    # 1. Load config
    cfg = load_config()
    net_cfg = cfg.get("network", {})
    proxy_timeout = int(net_cfg.get("proxy_timeout_sec", 15))
    delay_between_accs = int(net_cfg.get("delay_between_accounts_sec", 3))

    # 2. Discover accounts
    accounts = discover_all_accounts(ACCOUNTS_PATH, COOKIES_DIR)
    total_accs = len(accounts)

    if total_accs == 0:
        log_error("No accounts found in cookies/ folder or acc.txt file.")
        log_info("Please add accounts to acc.txt or save cookie files into cookies/ folder.")
        try:
            input(f"\n  {C.DIM}👉 Press Enter to exit...{C.RESET}")
        except Exception:
            pass
        return

    print(f"  {C.BOLD}{C.CYAN}AVAILABLE ACCOUNTS ({total_accs} total):{C.RESET}")

    cookie_group = [a for a in accounts if a.get("source") == "cookie"]
    txt_group = [a for a in accounts if a.get("source") == "txt"]

    idx_counter = 1
    if cookie_group:
        for a in cookie_group:
            px_display = a["proxy"].split("@")[-1] if "@" in a["proxy"] else (a["proxy"] or "Direct IP")
            print(f"    [{C.GREEN}{idx_counter}{C.RESET}] {C.BOLD}{a['email']}{C.RESET}  {C.GREEN}[COOKIE]{C.RESET} | Proxy: {C.GRAY}{px_display}{C.RESET}")
            idx_counter += 1

    if txt_group:
        for a in txt_group:
            px_display = a["proxy"].split("@")[-1] if "@" in a["proxy"] else (a["proxy"] or "Direct IP")
            print(f"    [{C.YELLOW}{idx_counter}{C.RESET}] {C.BOLD}{a['email']}{C.RESET}  {C.YELLOW}[PASS]{C.RESET}   | Proxy: {C.GRAY}{px_display}{C.RESET}")
            idx_counter += 1

    print(f"\n  {C.GRAY}──────────────────────────────────────────────────────────────────────{C.RESET}")
    print(f"  👉 Enter account number [{C.BOLD}1-{total_accs}{C.RESET}], email, or type '{C.GREEN}all{C.RESET}' to run all:")
    choice = input("  👉 Choice: ").strip()

    target_accounts: List[Dict[str, str]] = []
    is_batch_mode = False

    if choice.lower() == "all":
        target_accounts = accounts
        is_batch_mode = True
        log_info(f"Batch mode selected ({total_accs} accounts).")
    elif choice.isdigit() and 1 <= int(choice) <= total_accs:
        target_accounts = [accounts[int(choice) - 1]]
    else:
        search_key = choice.lower().strip()
        if not search_key and total_accs >= 1:
            target_accounts = [accounts[0]]
        else:
            matched = [a for a in accounts if search_key in a["email"].lower()]
            if matched:
                target_accounts = [matched[0]]
            else:
                log_error(f"No account matching '{choice}'.")
                try:
                    input(f"\n  {C.DIM}👉 Press Enter to exit...{C.RESET}")
                except Exception:
                    pass
                return

    # Session statistics
    stats = {
        "success_instant": 0,
        "success_pending": 0,
        "bad": 0,
        "rate_limited": 0,
        "need_verify": 0,
        "banned": 0,
        "failed": 0,
    }

    shared_batch_item: Optional[Dict[str, Any]] = None
    num_targets = len(target_accounts)

    for idx, acc in enumerate(target_accounts, 1):
        email = acc["email"]
        password = acc["password"]
        proxy = acc["proxy"]
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        print(f"\n  {C.CYAN}{'─' * 66}{C.RESET}")
        print(f"  {C.BOLD}[{idx}/{num_targets}] {email}{C.RESET}")
        print(f"  {C.CYAN}{'─' * 66}{C.RESET}")

        # 3.1: Check proxy connectivity
        if proxy:
            px_short = proxy.split("@")[-1] if "@" in proxy else proxy
            log_info(f"Testing proxy: {px_short}")
            if not test_proxy_live(proxy, timeout=proxy_timeout):
                log_error("Proxy unreachable. Stopping to prevent IP leak!")
                append_result("failed.txt", f"{email}:{password} | Proxy DIE: {proxy} | {now_str}")
                stats["failed"] += 1
                continue
            log_success("Proxy connected successfully!")
        else:
            log_info("Running on Direct IP (No proxy)")

        # 3.2: Login (Prioritize Cookies)
        session = None
        test_session = DirectSession(proxy_url=proxy)
        has_loaded_cookie = load_cookies_into_session(test_session, COOKIES_DIR, email)

        if has_loaded_cookie:
            log_info("Validating saved cookie session...")
            if is_session_alive(test_session):
                log_success("Cookie session valid! Skipping password.")
                session = test_session
            else:
                log_warn("Cookie expired. Switching to password login...")

        if not session and password:
            if "ANON=" in password or password.startswith(("[", "{")) or "RPSSecAuth=" in password:
                inline_ck = parse_cookie_content(password)
                if inline_ck:
                    test_session = DirectSession(proxy_url=proxy)
                    test_session.set_cookies_dict(inline_ck)
                    if is_session_alive(test_session):
                        log_success("Inline cookie session valid!")
                        session = test_session
                        save_cookies_file(COOKIES_DIR, email, inline_ck)

        if not session:
            if not password:
                log_error("Account has no password in acc.txt and cookie is unavailable.")
                append_result("bad.txt", f"{email}:Missing password & Cookie expired | {now_str}")
                stats["bad"] += 1
                continue

            log_info("Logging in via Direct OAuth...")
            status, session, err_msg = login_direct_oauth(
                email=email,
                password=password,
                proxy_url=proxy,
                timeout=proxy_timeout,
            )

            if status == "BAD":
                log_error(f"Invalid password: {err_msg}")
                append_result("bad.txt", f"{email}:{password} | {err_msg} | {now_str}")
                stats["bad"] += 1
                continue

            elif status == "RATE_LIMITED":
                log_error(f"Rate limited: {err_msg}")
                append_result("rate_limited.txt", f"{email}:{password} | {err_msg} | {now_str}")
                stats["rate_limited"] += 1
                continue

            elif status == "2FA":
                log_warn(f"2FA verification required: {err_msg}")
                append_result("need_verify.txt", f"{email}:{password} | {err_msg} | {now_str}")
                stats["need_verify"] += 1
                continue

            elif status == "LOCKED":
                log_error(f"Account locked / suspended: {err_msg}")
                append_result("banned.txt", f"{email}:{password} | {err_msg} | {now_str}")
                stats["banned"] += 1
                continue

            elif status != "HIT" or not session:
                log_error(f"Login failed: {err_msg}")
                append_result("failed.txt", f"{email}:{password} | Login error: {err_msg} | {now_str}")
                stats["failed"] += 1
                continue

            log_success("Login successful! New session saved.")
            save_cookies_file(COOKIES_DIR, email, session.get_cookies_dict())

        # 3.4: Fetch balance, region and ban status
        profile = get_profile_and_balance(session)
        balance = profile["balance"]
        country = profile["country"]
        year = profile["year"]
        ruid = profile["ruid"]

        print(f"  {C.BOLD}• Balance: {C.GREEN}{balance:,} pts{C.RESET} | Region: {C.CYAN}{country}{C.RESET} | Created: {year}")

        is_banned, ban_reason = check_is_banned(session)
        if is_banned:
            log_error(f"Account suspended by Microsoft Rewards: {ban_reason}")
            append_result("banned.txt", f"{email}:{password} | {ban_reason} | {now_str}")
            stats["banned"] += 1
            continue

        # 3.5: Load live gift card catalog
        reward_item: Optional[Dict[str, Any]] = None
        target_pts = 0

        if is_batch_mode and shared_batch_item:
            reward_item = shared_batch_item
            target_pts = int(reward_item["pointsCost"])
            log_info(f"Applying reward: {reward_item['title']} ({target_pts:,} pts)")

        else:
            log_info("Fetching live gift card catalog...")
            live_cards = fetch_live_account_giftcards(session, country=country)

            if not live_cards:
                log_error(f"No gift cards available for region [{country}].")
                append_result("failed.txt", f"{email}:{password} | No Gift Cards ({country}) | {now_str}")
                stats["failed"] += 1
                continue

            while True:
                print(f"\n  {C.BOLD}{C.MAGENTA}AVAILABLE GIFT CARDS [{country}]:{C.RESET}")
                for c_idx, c in enumerate(live_cards, 1):
                    print(f"    [{C.CYAN}{c_idx}{C.RESET}] {c['name']} {C.DIM}(From: {c['price']:,} pts){C.RESET}")

                print(f"  {C.GRAY}──────────────────────────────────────────────────────────────────────{C.RESET}")
                card_choice = input(f"  👉 Select card [1-{len(live_cards)}] (Enter = [1]): ").strip()
                sel_c_idx = int(card_choice) - 1 if card_choice.isdigit() and 1 <= int(card_choice) <= len(live_cards) else 0
                selected_card = live_cards[sel_c_idx]

                log_info(f"Fetching point tiers for '{selected_card['name']}'...")
                options = fetch_card_denominations(session, selected_card)

                print(f"\n  {C.BOLD}{C.MAGENTA}POINT TIERS FOR '{selected_card['name']}':{C.RESET}")
                for o_idx, opt in enumerate(options, 1):
                    p_cost = opt["points"]
                    is_oos = opt.get("is_out_of_stock", False)
                    if is_oos:
                        status_tag = f"{C.RED}[OUT OF STOCK]{C.RESET} {C.DIM}(Restocking){C.RESET}"
                    elif balance >= p_cost:
                        status_tag = f"{C.GREEN}[AFFORDABLE]{C.RESET}"
                    else:
                        status_tag = f"{C.RED}[INSUFFICIENT]{C.RESET}"
                    print(f"    [{C.CYAN}{o_idx}{C.RESET}] {opt['label']:<24} {C.BOLD}{p_cost:>6,} pts{C.RESET}  {status_tag}")

                all_oos = all(o.get("is_out_of_stock", False) for o in options)
                if all_oos:
                    log_error(f"All point tiers for '{selected_card['name']}' are currently OUT OF STOCK.")
                    print(f"  {C.YELLOW}👉 Please select a different gift card!{C.RESET}")
                    continue

                chosen_opt = None
                while True:
                    print(f"  {C.GRAY}──────────────────────────────────────────────────────────────────────{C.RESET}")
                    opt_choice = input(f"  👉 Select option [1-{len(options)}] (Enter = [1]): ").strip()
                    if opt_choice.lower() in ("b", "back"):
                        break
                    sel_o_idx = int(opt_choice) - 1 if opt_choice.isdigit() and 1 <= int(opt_choice) <= len(options) else 0
                    candidate_opt = options[sel_o_idx]

                    if candidate_opt.get("is_out_of_stock"):
                        log_warn(f"Point tier '{candidate_opt['label']}' is currently OUT OF STOCK on Microsoft Rewards.")
                        log_warn("('So popular we're restocking! Back soon' - Redeem button is disabled).")
                        in_stock_avail = [i + 1 for i, o in enumerate(options) if not o.get("is_out_of_stock")]
                        in_stock_str = ", ".join(f"[{i}]" for i in in_stock_avail)
                        print(f"  {C.YELLOW}👉 Please select an in-stock tier ({in_stock_str}) or type 'b' to go back.{C.RESET}\n")
                        continue

                    chosen_opt = candidate_opt
                    break

                if not chosen_opt:
                    continue

                selected_option = chosen_opt
                target_pts = selected_option["points"]
                reward_item = {
                    "title": f"{selected_card['name']} - {selected_option['label']}",
                    "id": selected_option["id"],
                    "pointsCost": target_pts,
                    "href": selected_card.get("href", ""),
                }

                if is_batch_mode:
                    shared_batch_item = reward_item
                    log_info(f"Saved selection '{reward_item['title']}' for remaining accounts!")
                break

        log_info(f"Selected: {C.BOLD}{reward_item['title']}{C.RESET} (-{target_pts:,} pts)")

        if balance < target_pts:
            log_warn(f"Current balance ({balance:,} pts) is less than required ({target_pts:,} pts)!")
            if not is_batch_mode:
                cont = input("  Do you want to proceed anyway? [y/N]: ").strip().lower()
                if cont not in ("y", "yes"):
                    append_result("failed.txt", f"{email}:{password} | Insufficient points ({balance}/{target_pts}) | {now_str}")
                    stats["failed"] += 1
                    continue
            else:
                append_result("failed.txt", f"{email}:{password} | Insufficient points ({balance}/{target_pts}) | {now_str}")
                stats["failed"] += 1
                continue

        # 3.6: Initiate redemption request
        pre_order = fetch_latest_order_status(session)
        initial_order_id = pre_order.get("orderId", "None")

        log_info("Submitting redemption request to server...")
        browser_res: Dict[str, Any] = {}
        init_status, qr_info, img_bytes, init_err = initiate_redemption_challenge(session, reward_item)

        if init_status == "BANNED":
            log_error(f"Account suspended: {init_err}")
            append_result("banned.txt", f"{email}:{password} | Banned: {init_err} | {now_str}")
            stats["banned"] += 1
            continue

        elif init_status == "INSTANT_SUCCESS":
            log_success("Redeemed instantly on server!")

        elif init_status == "NEED_QR_PASTE":
            sku_target = reward_item.get("id") or reward_item.get("href") or ""
            ck_file = COOKIES_DIR / f"{email}.txt"
            if not ck_file.exists():
                ck_file = COOKIES_DIR / f"{email}.json"

            browser_cfg = cfg.get("browser", {})
            headless_pref = bool(browser_cfg.get("headless", True))

            mode_text = "Headless Background" if headless_pref else "Visible Window"
            log_info(f"Bypassing Cloudflare Turnstile [{mode_text}]...")

            browser_res = auto_capture_qr_from_browser(
                email=email,
                sku=sku_target,
                proxy=proxy,
                cookie_file_path=ck_file,
                headless=headless_pref,
                session=session,
                ruid=ruid,
                country=country,
                config=cfg,
            )

            if browser_res.get("status") == "SUCCESS":
                log_success("Browser confirmed order automatically!")
                init_status = "INSTANT_SUCCESS"

            elif browser_res.get("status") == "OUT_OF_STOCK":
                log_error("This reward is currently OUT OF STOCK on Microsoft Rewards ('So popular we're restocking! Back soon').")
                append_result("failed.txt", f"{email}:{password} | Out of stock | {now_str}")
                stats["failed"] += 1
                continue

            else:
                # Check order history in case user approved on Bing app
                latest_order = fetch_latest_order_status(session)
                if latest_order.get("status") in ("SUCCESS_INSTANT", "SUCCESS_PENDING") and latest_order.get("orderId") not in ("None", ""):
                    log_success("Order detected in order history!")
                    init_status = "INSTANT_SUCCESS"
                else:
                    qr_target_url = browser_res.get("direct_link") or browser_res.get("qr_url")
                    parsed_qr = parse_qr_url(qr_target_url) if qr_target_url else None

                    if parsed_qr:
                        qr_info = parsed_qr
                    else:
                        item_url = qr_info.get("item_url") if qr_info else f"https://rewards.bing.com{reward_item.get('href', '')}"
                        log_warn("Could not automatically capture QR secret.")
                        print(f"  👉 Gift page URL: {item_url}")
                        qr_input = input("  👉 Paste QR image URL here (or press Enter to skip): ").strip()
                        parsed_qr = parse_qr_url(qr_input)
                        if not parsed_qr:
                            log_error("No valid QR code received.")
                            append_result("failed.txt", f"{email}:{password} | Missing QR | {now_str}")
                            stats["failed"] += 1
                            continue
                        qr_info = parsed_qr

        elif init_status != "SUCCESS" or not qr_info:
            log_error(f"Challenge initialization failed: {init_err}")
            append_result("failed.txt", f"{email}:{password} | Error: {init_err} | {now_str}")
            stats["failed"] += 1
            continue

        if init_status != "INSTANT_SUCCESS":
            image_code = ""
            if not img_bytes and browser_res and browser_res.get("code"):
                raw_b64 = browser_res["code"]
                if "base64," in raw_b64:
                    raw_b64 = raw_b64.split("base64,", 1)[1]
                try:
                    import base64
                    img_bytes = base64.b64decode(raw_b64)
                except Exception:
                    pass

            if img_bytes:
                log_info("Solving image captcha automatically...")
                image_code = resolve_captcha_4tiers(
                    image_bytes=img_bytes,
                    email=email,
                    config=cfg,
                    captchas_dir=CAPTCHAS_DIR,
                )

            log_info("Verifying Bing Android challenge (RSA-2048 + TOTP)...")
            access_tok = browser_res.get("access_token", "") if browser_res else ""
            verified, v_msg = verify_redemption_challenge(
                session=session,
                email=email,
                ruid=ruid,
                qr_info=qr_info,
                image_code=image_code,
                access_token=access_tok,
                country=country,
            )

            if not verified:
                latest = fetch_latest_order_status(session)
                if latest.get("status") in ("SUCCESS_INSTANT", "SUCCESS_PENDING"):
                    log_success("Order detected in order history!")
                    init_status = "INSTANT_SUCCESS"
                else:
                    log_error(f"Verification failed: {v_msg}")
                    append_result("failed.txt", f"{email}:{password} | Verification error: {v_msg} | {now_str}")
                    stats["failed"] += 1
                    continue

            log_success("Challenge verified successfully!")

            log_info("Submitting final order confirmation...")
            final_ok, final_msg, _ = finalize_order(session, reward_item.get("id", ""), reward_item.get("href", ""))
            if final_ok:
                log_success(final_msg)
            else:
                log_error(f"Final order failed: {final_msg}")
                append_result("failed.txt", f"{email}:{password} | Order error: {final_msg} | {now_str}")
                stats["failed"] += 1
                continue

        # 3.9: Query order history
        log_info("Checking order history for reward code...")
        time.sleep(2)
        order_info = fetch_latest_order_status(session)

        # Prioritize data directly from browser View Detail modal
        b_res = browser_res.get("order_result") if browser_res else None
        if b_res and isinstance(b_res, dict):
            if b_res.get("orderId") and b_res["orderId"] != "None":
                order_info["orderId"] = b_res["orderId"]
            if b_res.get("code") and b_res["code"] != "None":
                order_info["code"] = b_res["code"]
            if b_res.get("link") and b_res["link"] != "None":
                order_info["link"] = b_res["link"]
            if b_res.get("status") in ("SUCCESS_INSTANT", "SUCCESS_PENDING"):
                order_info["status"] = b_res["status"]

        order_status = order_info["status"]
        order_code = order_info["code"]
        order_link = order_info["link"]
        order_id = order_info["orderId"]

        # If code or link is present, classify as instant success
        if order_code not in ("None", "") or order_link not in ("None", ""):
            order_status = "SUCCESS_INSTANT"

        has_real_order = (
            order_id not in ("None", "")
            and order_id != initial_order_id
            and order_status in ("SUCCESS_INSTANT", "SUCCESS_PENDING")
        )

        if has_real_order and order_status == "SUCCESS_INSTANT":
            print(f"\n  {C.GREEN}{C.BOLD}╔══════════════════════════════════════════════════════════════════════╗")
            print(f"  ║  🎉 [SUCCESS] REWARD REDEEMED SUCCESSFULLY!                          ║")
            print(f"  ║  • Item     : {reward_item['title'][:48]:<48} ║")
            print(f"  ║  • PIN/Code : {order_code[:48]:<48} ║")
            if order_link not in ("None", ""):
                print(f"  ║  • Claim URL: {order_link[:48]:<48} ║")
            print(f"  ║  • Order ID : {order_id[:48]:<48} ║")
            print(f"  ╚══════════════════════════════════════════════════════════════════════╝{C.RESET}\n")
            append_result(
                "success.txt",
                f"{email} | {reward_item['title']} | -{target_pts} pts | PIN: {order_code} | Link: {order_link} | Order: {order_id} | {now_str}",
            )
            stats["success_instant"] += 1

        elif has_real_order and order_status == "SUCCESS_PENDING":
            print(f"\n  {C.YELLOW}{C.BOLD}╔══════════════════════════════════════════════════════════════════════╗")
            print(f"  ║  ⏳ [PENDING] ORDER IN PROGRESS (24H REVIEW)                          ║")
            print(f"  ║  • Item     : {reward_item['title'][:48]:<48} ║")
            print(f"  ║  • Order ID : {order_id[:48]:<48} ║")
            print(f"  ║  • Microsoft will deliver code within 24 hours.                      ║")
            print(f"  ╚══════════════════════════════════════════════════════════════════════╝{C.RESET}\n")
            append_result(
                "pending.txt",
                f"{email} | {reward_item['title']} | -{target_pts} pts | [PENDING 24H] | Order: {order_id} | {now_str}",
            )
            stats["success_pending"] += 1
        else:
            log_error(f"Order not recorded on Microsoft Rewards (Order ID: {order_id}).")
            append_result(
                "failed.txt",
                f"{email}:{password} | Order not recorded (Order ID: {order_id}) | {now_str}",
            )
            stats["failed"] += 1

        if is_batch_mode and idx < num_targets and delay_between_accs > 0:
            log_info(f"Waiting {delay_between_accs}s before next account...")
            time.sleep(delay_between_accs)

    # 4. Session Summary
    print(f"\n  {C.BOLD}{C.CYAN}════════════════════════ SESSION SUMMARY ════════════════════════{C.RESET}")
    print(f"  • Total accounts processed          : {num_targets}")
    print(f"  • {C.GREEN}Instant success with code (Instant) : {stats['success_instant']}{C.RESET}")
    print(f"  • {C.YELLOW}Pending approval (24h Review)       : {stats['success_pending']}{C.RESET}")
    print(f"  • {C.RED}Suspended / Banned accounts         : {stats['banned']}{C.RESET}")
    print(f"  • {C.RED}Bad credentials (Password error)    : {stats['bad']}{C.RESET}")
    print(f"  • {C.RED}Failed / Other errors               : {stats['failed']}{C.RESET}")
    print(f"  {C.BOLD}{C.CYAN}═════════════════════════════════════════════════════════════════{C.RESET}")
    print(f"  📁 Detailed reports saved to: {C.BOLD}Result/{C.RESET}\n")

    try:
        input(f"  {C.DIM}👉 Press Enter to exit...{C.RESET}")
    except Exception:
        pass


if __name__ == "__main__":
    main()
